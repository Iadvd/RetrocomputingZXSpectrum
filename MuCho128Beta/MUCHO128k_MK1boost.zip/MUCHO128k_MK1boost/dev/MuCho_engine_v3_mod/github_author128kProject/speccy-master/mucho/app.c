/*
 * Part of Jari Komppa's zx spectrum suite
 * https://github.com/jarikomppa/speccy
 * released under the unlicense, see http://unlicense.org
 * (practically public domain)
*/

#define IMAGE_FX

#define MEMORY_BASE 0x5b00

#include <string.h>

#define FONTHEIGHT 8
#define COLOR(BLINK, BRIGHT, PAPER, INK) (((BLINK) << 7) | ((BRIGHT) << 6) | ((PAPER) << 3) | (INK))
 
#include "yofstab.h"
#include "propfont.h"

unsigned char printbychar = 0;
unsigned char atleastonecharnonempty = 0;

unsigned int configWaitkey=0;
									
const unsigned char pattern[8] = 
{ 
    0x00, 
    0xC1, 
    0x32, 
    0x18, 
    0x0C, 
    0x26, 
    0xC1, 
    0x00  
};

const unsigned char selectpattern[8] = 
{ 
    0x00, 
    0x88, 
    0xcc, 
    0xee, 
    0xcc, 
    0x88, 
    0x00, 
    0x00  
};

const unsigned char prop_ht[16] = {24,24,24,18, 16,14,12,10, 8,15,14,13, 12,11,10,9};
const unsigned char prop_step[16] = {0,0,0,2, 2,2,2,2, 2,1,1,1, 1,1,1,1};

#define HWIF_IMPLEMENTATION
#include "hwif.c"

//extern void zx7_unpack(unsigned char *src, unsigned char *dst) __z88dk_callee __z88dk_fastcall;
extern void zx7_unpack(unsigned char *src)  __z88dk_fastcall;

#define KEY_PRESSED_UP (KEYDOWN(9) || KEYDOWN(Q) || KEYDOWN(W) || KEYDOWN(E) || KEYDOWN(R) || KEYDOWN(T) || KEYDOWN(Y) || KEYDOWN(U) || KEYDOWN(I) || KEYDOWN(O) || KEYDOWN(P))
#define KEY_PRESSED_DOWN (KEYDOWN(8) || KEYDOWN(A) || KEYDOWN(S) || KEYDOWN(D) || KEYDOWN(F) || KEYDOWN(G) || KEYDOWN(H) || KEYDOWN(J) || KEYDOWN(K) || KEYDOWN(L))
#define KEY_PRESSED_FIRE (KEYDOWN(0) || KEYDOWN(ENTER) || KEYDOWN(SPACE))

enum opcodeval
{
    OP_HAS,
    OP_NOT,
    
    OP_SET,
    OP_CLR,
    OP_XOR,

    OP_RND,

    OP_ATTR,
    OP_EXT,
    OP_IATTR,
    OP_DATTR,

    OP_GO,
    OP_GOSUB,
    
    OP_GT,
    OP_GTC,
    OP_LT,
    OP_LTC,
    OP_GTE,
    OP_GTEC,
    OP_LTE,
    OP_LTEC,
    OP_EQ,
    OP_EQC,
    OP_IEQ,
    OP_IEQC,
    
    OP_ASSIGN,
    OP_ASSIGNC,
    OP_ADD,
    OP_ADDC,
    OP_SUB,
    OP_SUBC    
};

unsigned char gState[128]; // game state - 128x8=1024 bits, which "shold" be enough
unsigned char gNumber[32]; // number store - 32 variables "should" be enough
unsigned char y8; // prg state
unsigned char *answer[16]; // collected answers
unsigned char answers; // count of answers
unsigned char attrib, iattrib, dattrib, attrib_c, iattrib_c;
unsigned short go, gosub; // room id:s for go and gosub values
unsigned short current_resource; // currently decompressed resource

unsigned char *dataptrGLOBAL;

// IADVD: config.txt getter... ;)  BEGIN
#define CFG_LANGUAGE 	49267
#define CFG_INTROA 		49268
#define CFG_INTROB 		49269
#define CFG_WAITKEY 	49270
#define CFG_BLINKBAR 	49271
#define CFG_TALKKEY 	49272
#define CFG_SHOWTALKKEY 49273
#define CFG_TOTALQ      49274
#define CFG_TOTALIMG    49275 // at 49275+1 starts tha images info (3 bytes per image)
// music array position = 49276+(CFG_TOTALIMG*3) (1 byte per room Q, total CFG_TOTALQ bytes)
// keep image array position = 49276+(CFG_TOTALIMG*3)+(CFG_TOTALQ) (1 byte per room Q, total CFG_TOTALQ bytes)
// sounds array position = 49276+(CFG_TOTALIMG*3)+(CFG_TOTALQ)+(CFG_TOTALQ) (1 byte per room Q, total CFG_TOTALQ bytes)
// image_id array position = 49276+(CFG_TOTALIMG*3)+(CFG_TOTALQ)+((CFG_TOTALQ)*2) (1 byte per room Q, total CFG_TOTALQ bytes)
// full_image array position = 49276+(CFG_TOTALIMG*3)+(CFG_TOTALQ)+((CFG_TOTALQ)*3) (1 byte per room Q, total CFG_TOTALQ bytes)

int var_CFG_TOTALQ;
int var_49276_plus_CFG_TOTALIMG_x3;

int getConfig(unsigned int memadd){
	unsigned char *cia;
	cia=(unsigned char *)(memadd);
	return *cia;
}

int getConfig_precalc(unsigned int memadd){
	return getConfig(var_49276_plus_CFG_TOTALIMG_x3+memadd);
} 

// IADVD: config.txt getters... ;)  END

//https://espamatica.com/zx-spectrum-assembly-space-battle-0x0a-joystick/#Joystick

unsigned char use_KempstonJoystick;
unsigned char use_SinclairJoystick;
unsigned char joystick_up;
unsigned char joystick_down;
unsigned char joystick_fire;

// voy a borrar

//#ifndef IMAGE_FX
void joystick_asm(void){
	__asm
		check_Kempston:
			in a, (#31)			; $1F=31
			bit 3, a
			jr z, check_abajo_K
		set_arriba_K:
			ld hl,#_joystick_up
			ld (hl), #1
		check_abajo_K:
			in a, (#31)			; $1F=31
			bit 2, a
			jr z, check_disparo_K
		set_abajo_K:
			ld hl,#_joystick_down
			ld (hl), #1
		check_disparo_K:
			in a, (#31)			; $1F=31
			bit 4, a
			ret z
		set_disparo_K:
			ld hl,#_joystick_fire
			ld (hl), #1
			ret
		
		check_Sinclair:
			in a, (#254)			; $FE=254
			bit 1, a
			jr nz, check_abajo_S
		set_arriba_S:
			ld hl,#_joystick_up
			ld (hl), #1
		check_abajo_S:
			in a, (#254)			; $FE=254
			bit 2, a
			jr nz, check_disparo_S
		set_abajo_S:
			ld hl,#_joystick_down
			ld (hl), #1
		check_disparo_S:
			in a, (#254)			; $FE=254
			bit 0, a
			ret nz
		set_disparo_S:
			ld hl,#_joystick_fire
			ld (hl), #1
			ret
			
	__endasm;
}
//#endif


void k_pars_zero(void){
	//joystick_up=0;
	//joystick_down=0;
	//joystick_fire=0;
	__asm
		ld A,#0
		ld (_joystick_up), A   ; joystick_up = 0
		ld (_joystick_down), A ; joystick_down = 0
		ld (_joystick_fire), A ; joystick_fire = 0
	__endasm;
}

void read_k_and_j(void){
	readkeyboard();
	k_pars_zero();
//#ifndef IMAGE_FX
	if (use_KempstonJoystick==1){
		__asm
			; check Kempston joystick 
			call check_Kempston
		__endasm;
	}
	if (use_SinclairJoystick==1){
		__asm
			; check Sinclair joystick 1
			call check_Sinclair
		__endasm;
	}
//#endif
}

void fadeout(void){
	__asm
		ld de,#7
		loopFOA:
			ld a,d
			cp #0
			jr nz,seguirFOA
			ld a,e
			cp #0
			ret z
		seguirFOA:
			ld hl,#22528
			ld bc,#768
		bucle_subFOA:
			ld a,b
			cp #0
			jr nz, seguirFOASUB
			ld a,c
			cp #0
			jr z,end_FOASUB
		seguirFOASUB:
			ld a,(hl)
			and #7
			cp #0
			jr z,alreadyblack
			ld a,(hl)
			dec a
			ld (hl),a
		alreadyblack:
			ld a,(hl)
			and #8+16+32
			cp #0
			jr z,alreadyblackP
			ld a,(hl)
			sub #8
			ld (hl),a
		alreadyblackP:
			inc hl
			dec bc
			jr bucle_subFOA
		end_FOASUB:
			dec de
			jr loopFOA
	__endasm;
}

void wait_a_key(void){
	readkeyboard();
	while (!KEY_PRESSED_UP && !KEY_PRESSED_DOWN && !KEY_PRESSED_FIRE && (joystick_fire==0) && (joystick_up==0) && (joystick_down==0))
	{                      
		read_k_and_j();
	}
	k_pars_zero();
	// continue when "unpressed"
	while (KEY_PRESSED_UP || KEY_PRESSED_DOWN || KEY_PRESSED_FIRE)
	{
		readkeyboard();
	}
	fadeout();
}

unsigned char CFG_WAITKEY_VAL=0;
unsigned char CFG_TALKKEY_VAL='@';
unsigned char CFG_SHOWTALKKEY_VAL=1;

#include "drawstring.c"


/*
void print_separator(void){
	unsigned short i;
    unsigned char j;
	for (j = 20*8; j < 21*8; j++)
		i=0;
		while(i<32){
			*(unsigned char*)(yofs[j]+i) = pattern[j & 7];
			i++;
		}
        //for (i = 0; i < 32; i++)
        //    *(unsigned char*)(yofs[j]+i) = pattern[j & 7];
}
*/

#define EXTRAGOINGDOWN_BIN              0
#define EXTRAALIENHITHERE_BIN           1
#define BADEND_OK1_BIN                  2
#define BADEND_OK2_BIN                  3
#define BADEND_OK4_BIN                  4
#define PAWNSHOP_BIN                    5
#define MOTEL_BIN                       6
#define BADEND_OK3_BIN                  7
#define ENDGOOD1_BIN                    8
#define EXTRAFURILLOPRESENTSES_BIN      9
#define EXTRAFURILLOPRESENTS_BIN        10
#define ROAD_AND_BASE_PANORAMA_BIN      11
#define PRESENTS_BIN                    12
#define DIANA_BIN                       13
#define HANGAR_BIN                      14

// this is the aPPack library hidden at screen position $4000 215 bytes move to $BEB0 (48816)
unsigned int address_data_img;
int tmpcalc;

void aux_adi(){
	address_data_img=getConfig(++tmpcalc);
}

int get_resource (int n) {
	
	//int tmpcalc=CFG_TOTALIMG+(n*3)+1;
	tmpcalc=CFG_TOTALIMG+(n*3);
	
	if (n==99){
		return 0;
	}
	
	//if (n!=99){
		// load address of image inside the bank
		//address_data_img=getConfig(++tmpcalc); // RAM bank of the image
		aux_adi();
		__asm
			ld hl,#_address_data_img
			ld a,(hl)
			ld (#48786),a
		__endasm;
		//address_data_img=getConfig(++tmpcalc); // High byte of image address inside the RAM bank
		aux_adi();
		__asm
			ld hl,#_address_data_img
			ld a,(hl)
			ld (#48784),a
		__endasm;
		//address_data_img=getConfig(++tmpcalc); // Low byte of image address inside the RAM bank
		aux_adi();
		__asm
			ld hl,#_address_data_img
			ld a,(hl)
			ld (#48785),a
		
			push hl
			push de
			push bc
			push ix
			push af
			
			call #48787		 
			
			pop af
			pop ix
			pop bc
			pop de
			pop hl
			
		__endasm;
		
		return 1;
	//}else{
		//return 0;
	//}
}

char decimal(unsigned char *d, unsigned char v, unsigned char step)
{
    unsigned char c;
    c = '0';
    while (v >= step)
	{
        v -= step;
        c++;
    }
    *d = c;
    return v;
}

void patchstring(unsigned char *aDataPtr)
{    
    unsigned char c = aDataPtr[0];
    
    aDataPtr++; // skip len byte
    
    while (c--)
    {
        if (aDataPtr[0] == 1)
        {
            //unsigned char ov, v;     
            current_resource = 0; // reset current resource so re-patching works
            unsigned char v = gNumber[aDataPtr[1]];
            unsigned char ov = v;
            if (ov > 99) v = decimal(aDataPtr, v, 100); else aDataPtr[0] = 128;
            if (ov > 9)  v = decimal(aDataPtr+1, v, 10); else aDataPtr[1] = 128;
            decimal(aDataPtr + 2, v, 1);
        }
        aDataPtr++; 
		//c--;
    }
}

unsigned char moveflg=1;

void moveline(unsigned char from, unsigned char to)
{
    unsigned char i, j;
    unsigned char* s = (unsigned char*)yofs[from];
    unsigned char* d = (unsigned char*)yofs[to];
	for (i = 0; i < 8; i++, s += 256-32, d += 256-32){
		for (j = 0; j < 32; j++, s++, d++){
			*d = 0;
			if (moveflg==1){
				*d = *s;
			}
		}
	}
}

void clearline(unsigned char startline)
{
	/*
    unsigned char i;
    unsigned char j;
    unsigned char* p = (unsigned char*)yofs[startline];
    for (i = 0; i < 8; i++, p += 256-32)
        for (j = 0; j < 32; j++, p++)
            *p = 0;    
	*/
	moveflg=0;
	moveline(startline,startline);
	moveflg=1;
}


void moveline_clearline_aux(unsigned char pivot){
	moveline(pivot,22*8);
    // clear one line
    clearline(pivot);
}

void clearbottom(void)
{
    unsigned short i, j;
	
	for (i = 20*32; i < 24*32; i++){
		*(unsigned char*)(0x5800+i) = ((i<(21*32))?dattrib:iattrib_c); 
	}
    
    for (j = 21*8; j < 24*8; j+=8)
        clearline(j);
}


void unpack_resource(unsigned short id)
{
    // dest = 0xd000, ~4k of scratch. A bit tight?
	
	unsigned short res = *((unsigned short*)(unsigned char*)(MEMORY_BASE + id * 2));	
		
	if (res != current_resource)
    {
		unsigned short v;
		for (v = 0; v < 4096; v++)
            *((unsigned char*)0xd000 + v) = 0;   
		
		zx7_unpack((unsigned char*)res);
		
		current_resource = res;
    }	
}

unsigned char xorshift8(void) 
{
    y8 ^= (y8 << 7);
    y8 ^= (y8 >> 5);
    return y8 ^= (y8 << 3);
}

unsigned int looper;
// image bright fx
unsigned char * attrpointer;

#ifdef IMAGE_FX
unsigned char xfrom,yfrom,xto,yto;
unsigned char xfrom2,yfrom2,xto2,yto2;
#endif

void blink_fx(unsigned char xf, unsigned char yf, unsigned char xt, unsigned char yt){
	unsigned char i,j;
	for (i=yf;i<=yt;i++){
		for (j=xf;j<=xt;j++)
		{
			attrpointer=(unsigned char *)(22528+(i*32)+j);
			if (*attrpointer<64){
				*attrpointer+=64;
			}else{
				*attrpointer-=64;
			}
		}
	}
}

void fx_aux_lights_asm(void){
	blink_fx(xfrom,yfrom,xto,yto); // efectos fx de cada imagen
	blink_fx(xfrom2,yfrom2,xto2,yto2); // efectos fx de cada imagen
}

//int cadencia;
void fx_lights_asm(void){
	++looper;
	if (looper>=5000){
		looper=0;
#ifdef IMAGE_FX
		fx_aux_lights_asm();
#endif
		// we could use getConfig(CFG_BLINKBAR)==1 but this way is faster
		__asm
			ld a,(#49271) // configFlashBar at 48784+487 0=OFF e.o.c. ON
			add a,#0
			ret z
		__endasm;
		//if (cadencia>1000){
			blink_fx(0,22,31,22); // mensajes del motor...
		//}
	}
}

unsigned char get_bit(unsigned short id)
{
    return !!(gState[id & 0xff] & 1 << (id >> 8));
}

void cls_param(unsigned short attridx, unsigned short pixel_byte_idx)
{
	for (; attridx < 20*32; attridx++)
	{
        *(unsigned char*)(0x5800+attridx) = attrib_c;
	}
	for (; pixel_byte_idx < 20*8; pixel_byte_idx+=8)
		 clearline(pixel_byte_idx);    
	
}

void cls(void)
{
	cls_param(0,0);
}

#define SET_BIT(x) gState[(x) & 0xff] |= 1 << ((x) >> 8)
	
void exec(unsigned char *dataptr)
{
    unsigned char c = *dataptr;
    
	switch (dataptr[1])
	{
        case 'I':
        case 'A':
        case 'Q': 
            //dataptr += 1+1+2; 
            //c -= 3; 
            //break;
			dataptr += 2; 
            c -= 2; // dejo pasar abajo... risky
        case 'O': 
            dataptr += 1+1; 
            c -= 1; 
            break;
        //case 'C':
        //    dataptr += 1+1+2+2;
        //    c -= 5;
        //    break;
    }
	  
    while (c)
    {
        // ignore predicate ops
        unsigned short id = *((unsigned short*)&dataptr[1]);
		unsigned short idcalc = (1 << (id >> 8));
		unsigned char idcalc2 = (id & 070) | (id >> 3);
		unsigned short dtp1=dataptr[1];
		unsigned short dtp2=dataptr[2];	
		unsigned short gNdtp2=gNumber[dtp2];
		switch (*dataptr)
        {
            case OP_SET:
                SET_BIT(id);
                break;
            case OP_CLR:
                gState[id & 0xff] &= (idcalc)^0xff;
				break;
            case OP_XOR:
                gState[id & 0xff] ^= idcalc;
				break;
            case OP_ATTR:
                attrib = id;
                attrib_c = idcalc2;
				break;
            case OP_IATTR:
                iattrib = id;
                iattrib_c = idcalc2; 
				break;
            case OP_DATTR:
                dattrib = id;
                break;                
            case OP_EXT:
                if (id < 8)
				{
					port254(id);
				}
				if (id == 8)
				{
					cls();
					clearbottom();
				}
				if (id == 9)
				{
					cls();
				}
				if (id == 10)
				{
					clearbottom();
				}
                break;                
            case OP_ASSIGN:
                gNumber[dtp1] = gNdtp2;
                break;
            case OP_ASSIGNC:
                gNumber[dtp1] = dtp2;
                break;
            case OP_ADD:
                gNumber[dtp1] += gNdtp2;
                break;
            case OP_ADDC:
                gNumber[dtp1] += dtp2;
                break;
            case OP_SUB:
                gNumber[dtp1] -= gNdtp2;
                break;
            case OP_SUBC:    
                gNumber[dtp1] -= dtp2;
                break;
            case OP_GO:
                go = id;
                break;
            case OP_GOSUB:
                gosub = id;
                break;
        }
        dataptr += 3;
        c -= 3;
    }    
}

unsigned char pred(unsigned char *dataptr)
{
    unsigned char c = *dataptr;
    unsigned char ret = 1;
    
    switch (dataptr[1])
    {
        case 'I':
        case 'A':
        case 'Q':
            dataptr += 1+1+2; 
            c -= 3; 
            break; 
        case 'O': 
            dataptr += 1+1; 
            c -= 1; 
            break;
        //case 'C':
        //    dataptr += 1+1+2+2;
        //    c -= 5;
        //    break;
    }
    
    while (c)
    {
        // ignore exec ops
        unsigned short id = *((unsigned short*)&dataptr[1]);
        unsigned char first = gNumber[dataptr[1]];
        unsigned char secondc = dataptr[2];
        unsigned char second = gNumber[secondc];
        switch (*dataptr)
        {
			case OP_HAS: if (!get_bit(id))        ret = 0; break;
            case OP_NOT: if ( get_bit(id))        ret = 0; break;
            case OP_RND: if (xorshift8() > id)    ret = 0; break;
            case OP_GT:  if (!(first >  second))  ret = 0; break;
            case OP_GTC: if (!(first >  secondc)) ret = 0; break;
            case OP_LT:  if (!(first <  second))  ret = 0; break;
            case OP_LTC: if (!(first <  secondc)) ret = 0; break;
            case OP_GTE: if (!(first >= second))  ret = 0; break;
            case OP_GTEC:if (!(first >= secondc)) ret = 0; break;
            case OP_LTE: if (!(first <= second))  ret = 0; break;
            case OP_LTEC:if (!(first <= secondc)) ret = 0; break;
            case OP_EQ:  if (!(first == second))  ret = 0; break;
            case OP_EQC: if (!(first == secondc)) ret = 0; break;
            case OP_IEQ: if (!(first != second))  ret = 0; break;
            case OP_IEQC:if (!(first != secondc)) ret = 0; break;
        }
        
        dataptr += 3;
        c -= 3;
    }
    return ret;
}

void add_answer(unsigned char *dataptr)
{
    answer[answers] = dataptr;
    if (answers != 15) answers++;
}

void drawattrib(unsigned char yofs, unsigned char attrib)
{
    unsigned char * dst = (unsigned char*)(0x5800 + yofs * 4);
    unsigned char i,j,k;
	/*
	for (i = 0; i < 32; i++)
    {
        *dst = attrib;
        dst++;

		// forzamos caracter a caracter
		if (printbychar==1){
			j=1;
			while(j++>0){
				k=0;
				while(k++<10){
				}
			}	
		}		
    }
	*/
	i=0;
	while(i++<32){
		*dst = attrib;
        dst++;

		// forzamos caracter a caracter
		//if (printbychar==1){
			//j=1;
			j=printbychar;
			while(j++>0){
				k=0;
				while(k++<10){
				}
			}	
		//}
	}
}

void drawattrib_iattrib(unsigned char yofs)
{
	printbychar=0;
	drawattrib(yofs,iattrib);
}

void aux_wpf(void){
	joystick_fire=0;
	while (KEY_PRESSED_FIRE)
	{
		readkeyboard();
	}   
}

int fx_please=1;
void aux_kb(void){
	readkeyboard();            
	while ((!KEY_PRESSED_FIRE)&&(joystick_fire==0))
	{
		if (fx_please==1){
			fx_lights_asm();
		}
		read_k_and_j();
	}
	//joystick_fire=0;
	aux_wpf();	
}

void common_hitkeytocontinue(void){
	drawattrib_iattrib(22*8);
	aux_kb();
	__asm
		call #49031
	__endasm;
    clearbottom();
}

/*
void hitkeytocontinue_EN(void)
{
    //              0123456789ABCDEF0123456789ABCDEF01
	drawstring("\x19         [Press space]   ", 6, 22*8);
}

void hitkeytocontinue_ES(void)
{
    //              0123456789ABCDEF0123456789ABCDEF01
	drawstring("\x19        [Pulsa espacio]  ", 6, 22*8);
}
*/

unsigned short hlreg;

void codeblock(unsigned char *dataptr)
{
    unsigned short id = *((unsigned short*)&dataptr[2]);
    hlreg = *((unsigned short*)&dataptr[4]);
    unpack_resource(id);
    asmstuff:
    __asm
        push hl
        ld hl, (#_hlreg)
        call #0xd000
        pop hl
    __endasm;

}

unsigned char * dst;
unsigned char x;

unsigned char *dataptrAUX;

void image_aux_for(void){
	for (x = 0; x < 32; x++)
	{
		*dst = *dataptrAUX;
		dataptrAUX++;
		dst++;
	}	
}

void aux_hitkeytocontLANG(){
	clearbottom();
	drawstring("\x19            [>>]         ", 6, 22*8);
	/*
	if (getConfig(CFG_LANGUAGE)==0){
		hitkeytocontinue_EN();
	}else{
		hitkeytocontinue_ES();
	}
	*/
	common_hitkeytocontinue();
}

void image(unsigned char *dataptr, unsigned char *aYOfs)
{
    unsigned short id = *((unsigned short*)&dataptr[2]);
    unsigned short yp, ayp;
    unsigned char y, rows;
    
    unpack_resource(id);
    
	dataptrAUX = (unsigned char*)0xd000;
	
    id = *dataptrAUX; // scanlines
	
    yp = *aYOfs;
    rows = id / 8;
	printbychar=0;
    for (y = 0; y < rows; y++)
        drawattrib(yp + y, attrib_c);
    if (id + yp > 20*8)
	{
		aux_hitkeytocontLANG();
		cls();
        yp = 0;
    }   
    
    ayp = yp * 4; // yp / 8 * 32 -> yp * 4
    
    dataptrAUX++;
	
	for (y = 0; y < id; y++, yp++)
    {
		dst = (unsigned char*)yofs[yp]; // this is screen memory (pixels)
		image_aux_for();
    }
    
    dst = (unsigned char*)(0x5800 + ayp); // hex 5800 is screen attr (colours)
    for (y = 0; y < rows; y++)
    {
        image_aux_for();
    }
    *aYOfs = yp;
						
}

unsigned short tester;

unsigned char * find_room(unsigned short id)
{
	unsigned char * dataptr = (unsigned char*)0xd000;
	
    unpack_resource(id);
	
	
        /*
        - code string
        - 0..n strings
        - 0        
        */
	
	while (1)
    {
        if (dataptr[1] == 'Q')
        {
			if (dataptr[2] == (id & 0xff) &&
                dataptr[3] == (id >> 8))
            {
                return dataptr;
            }
        }
        dataptr += *dataptr + 1;
        while (*dataptr)
        {
            dataptr += *dataptr + 1;
        }
        dataptr++;
    }
	
}

void exec_dpt(void){
	exec(dataptrGLOBAL); 
}

unsigned short room_id; 

void upkres_rid(void){
	unpack_resource(room_id);
}
	
unsigned char current_music=99;

void aux_intros(unsigned int memintro){
	if (getConfig(memintro)!=99){
		get_resource(getConfig(memintro));
		wait_a_key();
		//fadeout();									
	}
}

unsigned char image_height;

#ifdef IMAGE_FX
void reset_fx_arrays(void){
	__asm
		LD A, #0             ; Carga 0 en el acumulador (una sola vez)
		LD (_xfrom), A       ; xfrom = 0
		LD (_yfrom), A       ; yfrom = 0
		LD (_xto), A         ; xto = 0
		LD (_yto), A         ; yto = 0
		LD (_xfrom2), A      ; xfrom2 = 0
		LD (_yfrom2), A      ; yfrom2 = 0
		LD (_xto2), A        ; xto2 = 0
		LD (_yto2), A        ; yto2 = 0
	__endasm;
}
#endif				
				
void render_room(void)
{
    //unsigned char *dataptr;
    unsigned char *subreturn;
    unsigned char output_enable;
    unsigned char yofs;
    unsigned char p;
    unsigned char q;
	unsigned int i,k;
	
	unsigned short norewrite = 0;
		
restart:
    p = 0;
    q = 0;
    go = 0xffff;
    gosub = 0xffff;
    output_enable = 1;
    subreturn = 0;
    yofs = 0;
    dataptrGLOBAL = find_room(room_id);    
    SET_BIT(room_id);
	
	cls();
    
	//print_separator(); 
		
    while (*dataptrGLOBAL)
    {       
		printbychar=0; // reset print by char flag 
        p = pred(dataptrGLOBAL);
        switch (dataptrGLOBAL[1])
        {
            case 'Q': 
						
				norewrite = 0; // IADVD
				image_height=0;
				
#ifdef IMAGE_FX
				//reset_fx_arrays();
#endif

                if (q) // the next room
                {
                    return;
                }
                q = 1;
				// IADVD forced BEGIN
				attrib = 3;
                attrib_c = 0;
				// IADVD forced END
                if (p) 
                {
                    exec_dpt();
                }
                answers = 0;
				
				// posicion of music array = 49276+(CFG_TOTALIMG*3) (1 byte per room Q, total CFG_TOTALQ bytes)
				i=getConfig_precalc(room_id);
				if (current_music!=i){
					if (current_music!=99){
						//__asm
						//	call #49098 ; stop music
						//__endasm;
						current_music=i;
						switch(current_music){
							case 0:
								__asm
									call #49057 ; wyz_play_music_0
								__endasm;
								break;
							case 1:
								__asm
									call #49062 ; wyz_play_music_1
								__endasm;
								break;
							case 2:
								__asm
									call #49067 ; wyz_play_music_2
								__endasm;
								break;
							case 3:
								__asm
									call #49072 ; wyz_play_music_3
								__endasm;
								break;
							case 4:
								__asm
									call #49077 ; wyz_play_music_4
								__endasm;
								break;
							case 5:
								__asm
									call #49082 ; wyz_play_music_5
								__endasm;
								break;
						}
					}
				}
				if ((getConfig_precalc((2*var_CFG_TOTALQ)+room_id))==1){
					__asm
						ld l,#4
						call #49046
					__endasm;
				}
				// last part full screen image!
				k=getConfig_precalc((4*var_CFG_TOTALQ)+room_id);
				if ((room_id>0)&&(k!=99)){
					fx_please=0;
					get_resource(k);
					wait_a_key();
					//fadeout();
					fx_please=1;
					cls();
				}
                break;
            case 'I': 
                if (p)
                {
                    exec_dpt();
					
					// IADVD do not load again image if we keep same image always at top BEGIN
					//  this will ONLY work if by design rooms that show same image on top after
					//  press a key keep the same image until the end in the same yofs=8 beginning
					// position. This avoid the blinking of the reload of the image when the image
					// is the same one and in the same position.
					// this is a VERY customized change.
					if (norewrite==0){
						
						// special case for "main menu" room, which is the first room Q
						if (room_id==0){
							
							image(dataptrGLOBAL, &yofs); 
							// save injected library
							// this is the aPPack library hidden at screen position $4000 215 bytes move to $BEB0 (48816)
							__asm
								// stack at 39000 should be safer enough for the purpose of the beta engine
								push hl
								push de
								push bc
								push ix
								push iy
								push af
								ld de,#48784 		// 0xBEA0
								ld hl,#16384 		// 0x4000
								ld bc,#(492+150+500) //492
								// up to 483 bytes are RAM bank libraries, after that point we have some keys and then max 150 bytes of possible images
								// after that, max 200 bytes of keep image array and music array for each Q
								// CONFIG is included from pos 484 (484 to 492, total 8 bytes)
								
								// CFG_LANGUAGE: LANGUAGE/IDIOMA (ENGLISH/INGLES=0, SPANISH/CASTELLANO=1)
								// CFG_INTROA: SHOW INITIAL FULL SCREEN 1: 99=OFF
								// CFG_INTROB: SHOW INITIAL FULL SCREEN 2: 99=OFF
								// CFG_WAITKEY: IF THIS CHAR APPEARS IN THE TEXTS WILL BE REPLACED BY A PRESS KEY EVENT, WILL WAIT FOR PLAYER TO PRESS A KEY (0=OFF)
								// CFG_BLINKBAR: WILL INCREASE/DECREASE THE BRIGHT PARAMETER OF THE MENU SEPARATOR BAR (0=OFF)
								// CFG_TALKKEY: IF THIS CHAR APPEARS IN THE TEXTS THE CHARACTERS OF THE PARAGRAPHS WILL APPEAR ONE BY ONE (CONVERSATION EFFECT, 0=OFF)
								// CFG_SHOWTALKKEY: WHEN ACTIVATED, THE TALKKEY WILL BE REPLACED BY A SPACE (0=NOT REPLACED, 1=REPLACED)
								// CFG_TOTALQ: QUANTITY OF ROOMS, ASSUMING THAT THE ENGLISH AND SPANISH VERSIONS ARE IDENTICAL EXCEPT FOR THE LANGUAGE
								// CFG_TOTALIMG: QUANTITY OF IMAGESN IN RAM BANKS
								// MAX OF 3*50=150 bytes for image data 
								// MUSIC PER PLACE Q ARRAY (MAX 150 bytes)
								// KEEP IMAGE PER PLACE Q ARRAY (MAX 150 bytes)
								// SOUND PER PLACE Q ARRAY (MAX 150 bytes)
								// IMAGE_ID PER PLACE Q ARRAY (MAX 150 bytes)
								// FULL_IMAGE_ID PER PLACE Q ARRAY (MAX 150 bytes)
								
								ldir 			// rescue library to safe haven 0x96C0
								
								pop af
								pop iy
								pop ix
								pop bc
								pop de
								pop hl
								
								// music setup
								push hl
								push de
								push bc
								push ix
								push af
								push iy
								di
								call #49132; // set ISR requires initial di and final ei
								ei
								call #49122; // init music engine
								pop iy
								pop af
								pop ix
								pop bc
								pop de
								pop hl	
								
							__endasm;
							
							// set of several global vars
							var_CFG_TOTALQ=getConfig(CFG_TOTALQ);
							var_49276_plus_CFG_TOTALIMG_x3=49276+(3*getConfig(CFG_TOTALIMG));
							
							current_music=getConfig(var_49276_plus_CFG_TOTALIMG_x3);
							switch(current_music){
								case 0:
									__asm
										call #49057 ; wyz_play_music_0
									__endasm;
									break;
								case 1:
									__asm
										call #49062 ; wyz_play_music_1
									__endasm;
									break;
								case 2:
									__asm
										call #49067 ; wyz_play_music_2
									__endasm;
									break;
								case 3:
									__asm
										call #49072 ; wyz_play_music_3
									__endasm;
									break;
								case 4:
									__asm
										call #49077 ; wyz_play_music_4
									__endasm;
									break;
								case 5:
									__asm
										call #49082 ; wyz_play_music_5
									__endasm;
									break;
							}
						
							// Intro!!
							fx_please=0;
							
							CFG_WAITKEY_VAL=getConfig(CFG_WAITKEY);
							CFG_TALKKEY_VAL=getConfig(CFG_TALKKEY);
							CFG_SHOWTALKKEY_VAL=getConfig(CFG_SHOWTALKKEY);
							
							aux_intros(CFG_INTROA);
							aux_intros(CFG_INTROB);
							
							fadeout();
							fx_please=1;
							
							upkres_rid();
							yofs+=8;
						}
						
						k=getConfig_precalc((3*var_CFG_TOTALQ)+room_id);
						if (k==99){
							image(dataptrGLOBAL, &yofs); 
							upkres_rid();
							yofs+=8;
						}
						// RAM bank images
						if (get_resource(k)){
							// dynamically detect the height of the current image by finding the first not attr 0 line starting from the bottom
							unsigned char *cia;
							unsigned int newyofs;
							newyofs = 768-128; // except last 4 rows of the while screen that are reserverd for the MuCho's menu and separator (if any)
							cia=(unsigned char *)(23167); //23295-128 because last 4 rows are for MuCho's selection menu
							while (*cia==0){ // while attr is paper 0 and ink 0 
									newyofs--;
									cia--;
							}
							if ((newyofs%32)!=0){
								newyofs=newyofs+32;
							}
							newyofs/=32; // y offset calculation up-down
							yofs = (newyofs*8);
							image_height=yofs;//+8;
							
#ifdef IMAGE_FX
							__asm
								LD HL, #22520        ; Carga la dirección base en HL
								LD A, (HL)          ; Carga el valor de 22520 en A
								LD (_xfrom), A      ; Guarda el valor en _xfrom
								INC HL              ; HL apunta ahora a 22521
								LD A, (HL)          ; Carga el valor de 22521 en A
								LD (_yfrom), A      ; Guarda el valor en _yfrom
								INC HL              ; HL apunta ahora a 22522
								LD A, (HL)          ; Carga el valor de 22522 en A
								LD (_xto), A        ; Guarda el valor en _xto
								INC HL              ; HL apunta ahora a 22523
								LD A, (HL)          ; Carga el valor de 22523 en A
								LD (_yto), A        ; Guarda el valor en _yto
								INC HL              ; HL apunta ahora a 22524
								LD A, (HL)          ; Carga el valor de 22524 en A
								LD (_xfrom2), A      ; Guarda el valor en _xfrom
								INC HL              ; HL apunta ahora a 22525
								LD A, (HL)          ; Carga el valor de 22525 en A
								LD (_yfrom2), A      ; Guarda el valor en _yfrom
								INC HL              ; HL apunta ahora a 22526
								LD A, (HL)          ; Carga el valor de 22526 en A
								LD (_xto2), A        ; Guarda el valor en _xto
								INC HL              ; HL apunta ahora a 22527
								LD A, (HL)          ; Carga el valor de 22527 en A
								LD (_yto2), A        ; Guarda el valor en _yto
							__endasm;
#endif
							
						}
						
					}
                }
                break;
            //case 'C': 
            //    if (p)
            //    {
            //        exec_dpt();
            //        codeblock(dataptrGLOBAL); 
            //        upkres_rid();
            //    }
            //    break;
            case 'O': 
                if (p) 
                {
                    exec_dpt();
                    output_enable = 1;
                }
                else
                {
                    output_enable = 0;
                }
                break;
            case 'A':
                if (p && subreturn == 0) // no A:s from subpages
                {
                    add_answer(dataptrGLOBAL);
                }
                output_enable = 0;
                break;
        }
        dataptrGLOBAL += *dataptrGLOBAL + 1;
        
		while (*dataptrGLOBAL)
        {
			if (output_enable)
            {
				if (yofs + 8 > 20*8) 
                {
                    aux_hitkeytocontLANG();
					
					// IADVD avoid blinking when using same image on top after press a key BEGIN
					if ((getConfig_precalc(var_CFG_TOTALQ+room_id))==1){
						cls_param(image_height*4,image_height);
						norewrite=1;
						yofs=image_height;//10*8; // ya no es fijo, ahora ya es variable
					}else{
						cls();
						yofs = 0;
						image_height=0;
						
#ifdef IMAGE_FX
						reset_fx_arrays();
						/*
						xfrom=0;
						yfrom=0;
						xto=0;
						yto=0;
						
						xfrom2=0;
						yfrom2=0;
						xto2=0;
						yto2=0;
						*/
#endif						

					}
                }
				
				unsigned char temppbc = printbychar;
				printbychar=0;
				drawattrib(yofs, attrib_c);
				printbychar=temppbc;
				patchstring(dataptrGLOBAL);
				atleastonecharnonempty=0;
				drawstring(dataptrGLOBAL, 0, yofs);
				if (atleastonecharnonempty==0){
					printbychar=0; // empty line resets print by char flag
				}
				drawattrib(yofs, attrib);		
				yofs += 8;
				
            }
            dataptrGLOBAL += *dataptrGLOBAL + 1;
        }
        dataptrGLOBAL++;
        
        if (go != 0xffff)
        {
            room_id = go;
            goto restart;
        }
                
        if ((*dataptrGLOBAL == 0 || dataptrGLOBAL[1] == 'Q') && subreturn != 0)
        {
            dataptrGLOBAL = subreturn;
            subreturn = 0;
            upkres_rid();
        }

        if (gosub != 0xffff && subreturn == 0)
		{
            output_enable = 1;
            subreturn = dataptrGLOBAL;
            dataptrGLOBAL = find_room(gosub);
            SET_BIT(gosub);
            gosub = 0xffff;
            q = 0;
        }                
    }
    // if we get here, this was the last room in the data
}


void reset(void)
{
    unsigned short i;

	for (i = 0; i < 128; i++){ //256
		gNumber[i%32] = 0;
		gState[i] = 0;
	}
	
	/*
	attrib = 000;
    attrib_c = 000;
    iattrib = 000; 		//interface attr 071
    iattrib_c = 000;	//interface attr 077
    dattrib = 000;		//divider attr 072 blue and red
	*/
	__asm
		ld a,#0
		ld hl,#_attrib
		ld (hl),a
		ld hl,#_attrib_c
		ld (hl),a
		ld hl,#_iattrib
		ld (hl),a
		ld hl,#_iattrib_c
		ld (hl),a
		ld hl,#_dattrib
		ld (hl),a
	__endasm;
	
    cls();
    clearbottom();
    go = 0xffff;
    gosub = 0xffff;
    
    port254(0);// border

    y8 = 1;
    answers = 0;
    
    current_resource = 0;
}

unsigned char roller;

void drawselector(unsigned char y)
{    
    unsigned char i;   
    unsigned char v;
	unsigned short yofsy;
    roller++;
    v = (roller >> 5) & 7;
	
	for (i = 0; i < 8; i++,y++)
    {
        unsigned char p = 
            (selectpattern[i & 7] >> v) | (selectpattern[i & 7] << (8-v));
		yofsy=yofs[y];
        *(unsigned char*)(yofsy+0) = p & 0x1f | (*(unsigned char*)(yofsy+0) & 0x80);
        *(unsigned char*)(yofsy+1) = p & 0xf8;
    }
}

void prop_indicator(unsigned char current_answer)
{
    unsigned char ht = prop_ht[answers];
    unsigned char step = prop_step[answers];
    unsigned char ofs;
    unsigned char i;
    ofs = 168;
	for (i = 0; i < current_answer; i++)
        ofs += step;    
	for (i = 0; i < ht; i++)
        *((unsigned char*)yofs[ofs+i]) |= 0x80;
}

void end_msg_lang(void){
	drawstring((getConfig(CFG_LANGUAGE)==0)?"\x21[The end. Press space to restart]":"\x21[Fin. Pulsa espacio para empezar]", 6, 22*8);
}

void main(void)
{
    unsigned short i;
    unsigned char j;
    unsigned short current_room = 0;    
    unsigned char current_answer = 0;
    unsigned char selecting;    
	unsigned char recien_entrado = 1;
    
	looper=0;
	//cadencia=5000;
	
//#ifndef IMAGE_FX
	use_KempstonJoystick=0;
	use_SinclairJoystick=0;
//#endif
	k_pars_zero();
	
	// relocate sp
	__asm
		ld hl,#0
		add hl,sp
		ld sp,#48783 	// safe sp place 48784-1 BE8F
	__endasm;
	
	current_music=99;
	
	reset();     

    while(1)
    { 
        /*
        - code string
        - 0..n strings
        - 0        
        */
        clearbottom();
		room_id=current_room; // IADVD converted to a global var        
        
		fadeout();	
	
		render_room();
									
        if (answers == 0)
        {
			
			unsigned short t;
            clearbottom();
            // delay..
            for (j = 0; j < 4; j++)
            for (t = 0; t < 30000; t++);
            //              0123456789ABCDEF0123456789ABCDEF01

			end_msg_lang();
			drawattrib_iattrib(22*8);
            
			aux_kb();
			__asm
				call #49098
			__endasm;
			current_room = 0;
            current_answer = 0;
			recien_entrado=1;
			reset();       

        }
        else
        {
			unsigned char renderstate = 0;
            unsigned char last_answer_ofs = 0;
    
            if (current_answer >= answers)
                current_answer = 0;
            
            selecting = 1;
            while (selecting)
            {
                unsigned char answer_ofs = 0;
                unsigned char answer_yofs = 0;
                unsigned char selector_y = 0;
                                
                answer_ofs = current_answer;
                
				if (current_answer > 0)
				    answer_ofs -= 1;
                if (current_answer == answers-1)
                    answer_ofs -= 1;
				
                if (answers < 4) answer_ofs = 0;

                selector_y = 22*8;
                if (current_answer == 0) selector_y = 21*8;
                if (current_answer == answers-1 && answers > 2) selector_y = 23*8;
                
                /*
                 Four cases:
                 0. Open page: have to draw everything in any case.
                 1. Just move pointer, don't draw text (top/bottom/less than 4 answers)
                 2. Move answers up, draw one
                 3. Move answers down, draw one
                 */

                if (renderstate)
                {
					if (answer_ofs > last_answer_ofs)
                        renderstate = 2;
                    if (answer_ofs < last_answer_ofs)
                        renderstate = 3;
                }

                last_answer_ofs = answer_ofs;                
                 
                if (renderstate == 0)
                {
                    clearbottom();
                    
                    answer_yofs = 21*8;
                    for (i = 0; i < 3; i++, answer_yofs += 8)
                    {
                        if (answer_ofs + i < answers)
                        {
                            unsigned char *dataptr = answer[answer_ofs + i];
                            unsigned char roll = 0;
                            dataptr += *dataptr + 1;
                            patchstring(dataptr);
                            drawstring(dataptr, 1, answer_yofs);
                        }
                    }
                    
                    drawattrib_iattrib(21*8);
					drawattrib_iattrib(22*8);
					drawattrib_iattrib(23*8);
					
                }
                else
                {
                    // clear the selector area
					for (j = 168; j < 192; j++)
                    {
						i=yofs[j];
                        *(unsigned char*)(i++) = 0;
                        *(unsigned char*)(i) = 0;
                    }
					
                }                                                             
                
				if (renderstate == 2)
                {
                    // move up
					moveline(22*8,21*8);
                    moveline_clearline_aux(23*8);
					// draw one line
                    answer_yofs = 184;
                    answer_ofs += 2;
                }
                
                if (renderstate == 3)
                {
                    // move down
					moveline(22*8,23*8);
                    moveline_clearline_aux(21*8);
					// draw one line
                    answer_yofs = 168;
                }
				
                if (renderstate > 1)
                {
                    unsigned char *dataptr = answer[answer_ofs];
                    dataptr += *dataptr + 1;
                    patchstring(dataptr);
                    drawstring(dataptr, 1, answer_yofs);
                }
                
                renderstate = 1;
                
                prop_indicator(current_answer);
				
				read_k_and_j();
				while ((!(KEY_PRESSED_UP)) && (!(KEY_PRESSED_DOWN)) && (!(KEY_PRESSED_FIRE)) && (joystick_fire==0) && (joystick_up==0) && (joystick_down==0))
				//while (!KEY_PRESSED_UP && !KEY_PRESSED_DOWN && !KEY_PRESSED_FIRE && (joystick_fire==0))
				{        
					drawselector(selector_y);
					
					read_k_and_j();
#ifdef IMAGE_FX
					++looper;
					if (looper>=1000){
						looper=0;
						fx_aux_lights_asm();
					}
#endif
				}
				
				if ((KEY_PRESSED_FIRE)||(joystick_fire==1))
				{
					unsigned char *dataptr = answer[current_answer];
                    unsigned short id = *((unsigned short*)&dataptr[2]);
					
					aux_wpf();
					
					__asm
						call #49031
					__endasm;
						
                    selecting = 0;
                    exec(answer[current_answer]);
					
                    if (current_room != id)
                        current_answer = 0;

                    current_room = id;

//#ifndef IMAGE_FX
					if (current_room==1){
						// Activate Kempston Koystick 
						use_KempstonJoystick=1;
					}
					if (current_room==2){
						// Activate Sinclair Koystick 
						use_SinclairJoystick=1;
					}
//#endif

                }
                
                if ((KEY_PRESSED_UP)||(joystick_up==1))
                {
					while ((KEY_PRESSED_UP)||(joystick_up==1))
                    {
                        read_k_and_j();
                    }
					
					__asm
						call #49041 // wyz_play_sound_3
					__endasm;
					joystick_up=0;
					if (current_answer > 0)
                        current_answer--;
                }
                
                if ((KEY_PRESSED_DOWN)||(joystick_down==1))
                {
					while ((KEY_PRESSED_DOWN)||(joystick_down==1))
                    {
                        read_k_and_j();
                    }
					joystick_down=0;
					__asm
						call #49041 // wyz_play_sound_3
					__endasm;
					
					if (current_answer+1 < answers)
                        current_answer++;
                }                                
                
                xorshift8();    
            }
        }
    }
}
