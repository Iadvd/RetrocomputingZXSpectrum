#asm


; *****************************************************************************
; * The Music Studio Player Engine
; *
; * Based on code written by Sa#a Pu#ica for the utility, The Music Studio.
; * Modified by Chris Cowley
; *
; * Produced by Beepola v1.08.01
; ******************************************************************************

.musicstart
             LD    HL,MUSICDATA         ;  <- Pointer to Music Data. Change
			 JP    COMMON_ENGINE
.common_engine               
			LD   A,(HL)                         ; Get the loop start pointer
			LD   (PATTERN_LOOP_BEGIN),A
			INC  HL
			LD   A,(HL)                         ; Get the song end pointer
			LD   (PATTERN_LOOP_END),A
			INC  HL
			LD   (PATTERNDATA1),HL
			LD   (PATTERNDATA2),HL
			LD   A,254
			LD   (PATTERN_PTR),A                ; Set the pattern pointer to zero
			
			EXX
		    PUSH  HL
		    CALL  NEXT_PATTERN
		    POP   HL
		    EXX                                 
		    ;EI
		    RET

.nextnote
						  ;DI
						  EXX
                          PUSH  HL
                          CALL  PLAYNOTE

                          POP   HL
                          EXX 
						  ;EI
						  RET                                       ; Return from playing tune

.pattern_ptr              DEFB 0
.note_ptr                 DEFB 0


; ********************************************************************************************************
; * NEXT_PATTERN
; *
; * Select the next pattern in sequence (and handle looping if we''ve reached PATTERN_LOOP_END
; * Execution falls through to PLAYNOTE to play the first note from our next pattern
; ********************************************************************************************************
.next_pattern
                          LD   A,(PATTERN_PTR)
                          INC  A
                          INC  A
                          DEFB $FE                           ; CP n
.pattern_loop_end         DEFB 0
                          JR   NZ,NO_PATTERN_LOOP
                          DEFB $3E                           ; LD A,n
.pattern_loop_begin       DEFB 0
.no_pattern_loop          LD   (PATTERN_PTR),A
			                    DEFB $21                            ; LD HL,nn
.patterndata1             DEFW $0000
                          LD   E,A                            ; (this is the first byte of the pattern)
                          LD   D,0                            ; and store it at TEMPO
                          ADD  HL,DE
                          LD   E,(HL)
                          INC  HL
                          LD   D,(HL)
                          LD   A,(DE)                         ; Pattern Tempo -> A
	                	      LD   (TEMPO),A                      ; Store it at TEMPO

                          LD   A,1
                          LD   (NOTE_PTR),A

.playnote 
			                    DEFB $21                            ; LD HL,nn
.patterndata2             DEFW $0000
                          LD   A,(PATTERN_PTR)
                          LD   E,A
                          LD   D,0
                          ADD  HL,DE
                          LD   E,(HL)
                          INC  HL
                          LD   D,(HL)                         ; Now DE = Start of Pattern data
                          LD   A,(NOTE_PTR)
                          LD   L,A
                          LD   H,0
                          ADD  HL,DE                          ; Now HL = address of note data
                          LD   D,(HL)
                          LD   E,1

; IF D = $0 then we are at the end of the pattern so increment PATTERN_PTR by 2 and set NOTE_PTR=0
                          LD   A,D
                          CP   $FE
                          JR   Z,NEXT_PATTERN

.continue0                PUSH DE
                          INC  HL
                          LD   D,(HL)
                          LD   E,1

                          LD   A,(NOTE_PTR)
                          INC  A
                          INC  A
                          LD   (NOTE_PTR),A                   ; Increment the note pointer by 2 (one note per chan)

                          EXX
                          POP  DE                            

                          LD   A,(TEMPO)
                          LD   C,A
                          LD   B,0
						  LD   A,0
                          EX   AF,AF
						  LD   A,0 
                          EXX             ; Play silence

.output_note              LD   IXH,D                        
                          LD   H,D
                          LD   L,H
                          DEC  L
                          LD   E,L
                          JR   Z,CONTINUE1
                          LD   E,$10

.continue1
                          EXX
                          LD   IXL,D                          ; Put note frequency for chan 2 into IXL
                          LD   H,D
                          LD   L,H
                          DEC  L
                          LD   E,L
                          JR   Z,CONTINUE2
                          LD   E,$10
						  
.continue2
                          EXX
                          EX   AF,AF
                          OUT  ($FE),A
                          DEC  H             ; Dec H, which also holds the frequency value
                          JR   NZ,L8055
                          XOR  E
                          LD   H,D
                          PUSH AF
                          LD   A,IXH
                          CP   $20
                          JR   NC,L8054      ; if A > $20 then this is not a drum effect, skip the INC D
                          INC  D             ; create the "fast falling pitch" percussion effect
.l8054                    POP  AF
.l8055                    DEC  L
                          JR   NZ,L805B
                          XOR  E
                          LD   L,D
                          DEC  L
.l805b                    EXX
                          EX   AF,AF
                          OUT  ($FE),A
                          DEC  H
                          JR   NZ,L806D
                          XOR  E
                          LD   H,D
                          PUSH AF
                          LD   A,IXL
                          CP   $20
                          JR   NC,L806C     ; if A > $20 then this is not a drum effect, skip the INC D
                          INC  D            ; create the "fast falling pitch" percussion effect
.l806c                     POP  AF
.l806d                     DEC  L
                          JR   NZ,L8073
                          XOR  E
                          LD   L,D
                          DEC  L
.l8073                     DJNZ CONTINUE2
                          DEC  C
                          JR   NZ,CONTINUE2
                          RET

; *** DATA ***
.TEMPO                    DEFB 238

.MUSICDATA
                    DEFB 0   ; Loop start point * 2
                    DEFB 16   ; Song Length * 2
.PATTERNDATA        DEFW      PAT0
                    DEFW      PAT0
                    DEFW      PAT2
                    DEFW      PAT3
                    DEFW      PAT0
                    DEFW      PAT0
                    DEFW      PAT6
                    DEFW      PAT7

; *** Pattern data consists of pairs of frequency values CH1,CH2 with a single $FE to
; *** Mark the end of the pattern, and $01 for a rest
.PAT0
         DEFB 17  ; Pattern tempo
             DEFB 91,30
             DEFB 81,23
             DEFB 72,30
             DEFB 68,23
             DEFB 1,1
             DEFB 54,1
             DEFB 91,30
             DEFB 1,1
             DEFB 54,1
             DEFB 68,30
             DEFB 1,1
             DEFB 54,1
         DEFB $FE
.PAT2
         DEFB 17  ; Pattern tempo
             DEFB 68,30
             DEFB 61,23
             DEFB 54,30
             DEFB 51,23
             DEFB 1,1
             DEFB 40,30
             DEFB 68,1
             DEFB 1,1
             DEFB 40,1
             DEFB 51,30
             DEFB 1,1
             DEFB 40,1
         DEFB $FE
.PAT3
         DEFB 17  ; Pattern tempo
             DEFB 68,30
             DEFB 61,23
             DEFB 54,30
             DEFB 51,23
             DEFB 1,1
             DEFB 40,1
             DEFB 68,30
             DEFB 1,1
             DEFB 40,1
             DEFB 51,30
             DEFB 1,1
             DEFB 40,1
         DEFB $FE
.PAT6
         DEFB 17  ; Pattern tempo
             DEFB 61,30
             DEFB 54,23
             DEFB 48,30
             DEFB 45,23
             DEFB 1,1
             DEFB 36,1
             DEFB 61,30
             DEFB 1,1
             DEFB 36,1
             DEFB 45,30
             DEFB 1,1
             DEFB 36,1
         DEFB $FE
.PAT7
         DEFB 17  ; Pattern tempo
             DEFB 45,30
             DEFB 40,23
             DEFB 45,30
             DEFB 51,23
             DEFB 1,1
             DEFB 40,1
             DEFB 68,30
             DEFB 1,1
             DEFB 40,1
             DEFB 51,30
             DEFB 1,1
             DEFB 40,1
         DEFB $FE
		 
#endasm