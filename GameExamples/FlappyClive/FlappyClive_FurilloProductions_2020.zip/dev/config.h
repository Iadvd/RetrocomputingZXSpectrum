// Config.h
// Churrera v.4
// Copyleft 2010, 2011 The Mojon Twins

// ============================================================================
// I. General configuration
// ============================================================================

// In this section we define map dimmensions, initial and authomatic ending conditions, etc.

#define PLAYER_INI_X			4		//
#define PLAYER_INI_Y			10		// Initial tile coordinates

// ============================================================================
// III. Screen configuration
// ============================================================================

// This sections defines how stuff is rendered, where to show counters, etcetera

#define VIEWPORT_X				0		//
#define VIEWPORT_Y				0		//

//#define SPANISH_VER					// Spanish version! ;)
