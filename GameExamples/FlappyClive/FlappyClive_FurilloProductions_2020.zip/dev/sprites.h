// Sprites.h
// Generado por SprCnv de la Churrera
// Copyleft 2010 The Mojon Twins
 
extern unsigned char sprite_1_a []; 
extern unsigned char sprite_1_b []; 
extern unsigned char sprite_1_c []; 
extern unsigned char sprite_2_a []; 
extern unsigned char sprite_2_b []; 
extern unsigned char sprite_2_c []; 
extern unsigned char sprite_3_a []; 
extern unsigned char sprite_3_b []; 
extern unsigned char sprite_3_c []; 
extern unsigned char sprite_4_a []; 
extern unsigned char sprite_4_b []; 
extern unsigned char sprite_4_c []; 
 
#asm
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_1_a
        defb 6, 198
        defb 3, 227
        defb 1, 241
        defb 0, 252
        defb 2, 226
        defb 1, 193
        defb 0, 128
        defb 0, 24
        defb 0, 88
        defb 0, 56
        defb 0, 204
        defb 0, 200
        defb 0, 128
        defb 0, 49
        defb 0, 251
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_1_b
        defb 248, 251
        defb 8, 8
        defb 240, 244
        defb 144, 150
        defb 8, 8
        defb 176, 176
        defb 160, 161
        defb 160, 163
        defb 0, 3
        defb 0, 3
        defb 0, 1
        defb 0, 9
        defb 0, 121
        defb 0, 242
        defb 0, 240
        defb 0, 252
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_1_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_2_a
        defb 6, 198
        defb 3, 227
        defb 1, 177
        defb 0, 156
        defb 1, 25
        defb 0, 128
        defb 0, 192
        defb 0, 224
        defb 0, 240
        defb 0, 248
        defb 0, 248
        defb 0, 248
        defb 0, 240
        defb 0, 224
        defb 0, 227
        defb 0, 231
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_2_b
        defb 248, 251
        defb 8, 11
        defb 144, 151
        defb 224, 239
        defb 16, 17
        defb 160, 160
        defb 160, 160
        defb 0, 4
        defb 0, 8
        defb 0, 10
        defb 0, 28
        defb 0, 15
        defb 0, 143
        defb 0, 143
        defb 0, 31
        defb 0, 7
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_2_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_3_a
        defb 7, 199
        defb 3, 227
        defb 1, 241
        defb 0, 252
        defb 2, 162
        defb 0, 0
        defb 0, 224
        defb 0, 128
        defb 0, 128
        defb 0, 224
        defb 0, 192
        defb 0, 128
        defb 0, 128
        defb 0, 192
        defb 0, 193
        defb 0, 159
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_3_b
        defb 248, 251
        defb 216, 219
        defb 240, 247
        defb 144, 151
        defb 8, 9
        defb 0, 1
        defb 96, 97
        defb 96, 97
        defb 96, 99
        defb 0, 1
        defb 96, 96
        defb 0, 0
        defb 0, 1
        defb 0, 35
        defb 0, 199
        defb 0, 223
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_3_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
	._sprite_4_a
        defb 6, 230
        defb 3, 243
        defb 1, 249
        defb 0, 142
        defb 48, 180
        defb 48, 176
        defb 48, 48
        defb 56, 56
        defb 121, 121
        defb 124, 124
        defb 15, 143
        defb 119, 119
        defb 112, 112
        defb 112, 112
        defb 0, 143
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_4_b
        defb 248, 251
        defb 8, 11
        defb 240, 247
        defb 0, 15
        defb 0, 31
        defb 32, 39
        defb 40, 43
        defb 20, 21
        defb 2, 2
        defb 6, 6
        defb 202, 202
        defb 241, 241
        defb 4, 4
        defb 0, 96
        defb 0, 241
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_4_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
#endasm
 
