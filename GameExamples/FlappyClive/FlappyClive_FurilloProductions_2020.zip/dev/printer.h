// Printing functions

// Funci�n que pinta un tile para mapas packed

// uses special_color
int draw_coloured_tile (unsigned char x, unsigned char y, unsigned char t) {
	unsigned char k;
	
	t = 64 + (t << 2);
	allpurposepuntero = (unsigned char *) &tileset [2048 + t];
	// tileset has 2048 tiles and their 256 attr values
	#asm 
		ld a,0
		ld (_gpit),a
	#endasm
	while(gpit<4){
		sp_PrintAtInv (y+(gpit<2?0:1), x+(gpit%2), allpurposepuntero [gpit], t+(gpit++));
	}
	
}

// changes the attributes of a chosen tile
int colorize_tile_helper(int tile_number, int spec_color){
	int i;
	allpurposepuntero = (unsigned char *) &tileset [2048 + 64 + (tile_number << 2)];
	i=-1;
	while(i++<3){
		allpurposepuntero[i]=spec_color;
		if (tile_number==9&&(i%2==1)){
			break;
		}
	}
}			

// writes from right to left
void print_number1(unsigned char x, unsigned char y, unsigned char c, unsigned int number) {
	if (number>0){
		sp_PrintAtInv (y, x, c, 16 + (number%10));
		print_number1(x-1,y,c,number/10);
	}
}

int print_str (unsigned char x, unsigned char y, unsigned char c, unsigned char *s) {
	while (*s)	{
		sp_PrintAtInv (y, x ++, c, (*s ++) - 32);
	}
}

void blackout_area () {
	// blackens gameplay area for LEVEL XX display
	#asm
		ld hl, 22528
		ld bc,768
		loop_bout:
			ld (hl),0
			inc hl
			dec bc
			ld a,b
			add 0
			jp nz,loop_bout
			ld a,c
			add 0
			jp nz,loop_bout
			ret
	#endasm
}

// ASM ROUTINES BEGIN

extern unsigned char xc;
extern unsigned char yc;

#asm

rotate_palette:
		ld (_asm_int_d),a
		call nextnote
		ld a,(_col)
		dec a
		cp 1
		jp nz,no_loop_color
		ld a,6
		ld (_col),a
no_loop_color:
		ld (_col),a
		ld a,(_asm_int_b) ; HI dir of 22528+k (screen)
		ld d,a 
		ld a,(_asm_int_c) ; LO dir of 22528+k (screen)
		ld e,a 
		ld a,(_asm_int_d) ; qty < 256
		add 0
		jp z,end_rotate		
next_item: 
		push af
		ld a, (_col)
		ld (de),a
		inc de
		pop af
		dec a
		jp nz, next_item
end_rotate:
		ret

copy_to_screen_buffer:
	ld hl,16384
	ld de,_screen_buffer
	ld bc,6912
	ldir
	ret

move_buffer_to_screen:
	ld hl,_screen_buffer
	ld de,16384
	ld bc,6912
	ei
	halt
	ldir
	di
	ret

erotulos:
	ld hl,22801 //22528+273
	call change_bright
	ld hl,22833 //22528+273+32
	call change_bright
	ld hl,22865 //22528+273+64
	call change_bright
	ld hl,22897 //22528+273+96
	call change_bright
	
	ld hl,22805 
	call change_bright
	ld hl,22837 
	call change_bright
	ld hl,22869 
	call change_bright
	ld hl,22901 
	call change_bright
	
	ld hl,22809-1 
	call change_bright
	ld hl,22841-1
	call change_bright
	ld hl,22873-1
	call change_bright
	ld hl,22904-1
	call change_bright
	ret
	
efectillo_brillo_banner:
	ld hl,22528
	call change_bright
	ld hl,22560
	call change_bright
	ld hl,22592
	call change_bright
	ld hl,22624
	call change_bright
	ret

change_bright:
	ld a,0
starter_a:
	cp 4//10
	jp z, endstarter
	push af
	ld a,(hl)
	cp 64
	jp c, dobright
	sub 64
	ld (hl),a
	inc hl
	pop af
	inc a
	jp starter_a
dobright:
	add a,64
	ld (hl),a
	inc hl
	pop af
	inc a
	jp starter_a
endstarter:
	ret

#endasm

// ASM ROUTINES END