// Motor.h

// Normal animation:
unsigned char *player_frames [] = {
	sprite_1_a, sprite_2_a, sprite_3_a, sprite_4_a
};
unsigned char *player_framesB [] = {
	Bsprite_1_a, Bsprite_2_a, Bsprite_3_a
};

void saca_a_todo_el_mundo_de_aqui () {	
	sp_MoveSprAbs (sp_player, spritesClip, 0, VIEWPORT_Y + 30, VIEWPORT_X + 20, 0, 0);					
	sp_MoveSprAbs (sp_playerB, spritesClip, 0, VIEWPORT_Y + 30, VIEWPORT_X + 20, 0, 0);					
	sp_UpdateNow();
	espera_pasiva(ESPERA_PASIVA2);
}

// Render main character
int rmc(int which_frame){
	int x,y,yB;
	
	x = player.x >> 6;
	y = player.y >> 6;
	yB = y-16;
	sp_MoveSprAbs (sp_player, spritesClip, player.next_frame - player.current_frame, VIEWPORT_Y + (y >> 3), VIEWPORT_X + (x >> 3), x & 7, y & 7);					
	sp_MoveSprAbs (sp_playerB, spritesClip, playerB.next_frame - playerB.current_frame, VIEWPORT_Y + (yB >> 3), VIEWPORT_X + (x >> 3), x & 7, yB & 7);
	player.current_frame = player.next_frame;
	playerB.current_frame = playerB.next_frame;	
	if ( which_frame<2 && accumulated_invincibility>0){
		player.next_frame = player_frames [3];
	}else{
		player.next_frame = player_frames [which_frame];
	}
	playerB.next_frame = player_framesB [which_frame];
	sp_UpdateNow();
}

void Setup_Tileset_Sprites(void){
	int i=0;
	
	// Load tileset
	allpurposepuntero = tileset;
	while_library(255,21);

	// Clipping rectangle
	spritesClipValues.row_coord = VIEWPORT_Y;
	spritesClipValues.col_coord = VIEWPORT_X;
	spritesClipValues.height = 24;
	spritesClipValues.width = 32;
	spritesClip = &spritesClipValues;
	
	// Sprite creation
	sp_player = sp_CreateSpr (sp_MASK_SPRITE, 3, sprite_2_a, 1, TRANSPARENT);
	sp_AddColSpr (sp_player, sprite_2_b, TRANSPARENT);
	sp_AddColSpr (sp_player, sprite_2_c, TRANSPARENT);
	sp_playerB = sp_CreateSpr (sp_MASK_SPRITE, 3, Bsprite_2_a, 1, TRANSPARENT);
	sp_AddColSpr (sp_playerB, Bsprite_2_b, TRANSPARENT);
	sp_AddColSpr (sp_playerB, Bsprite_2_c, TRANSPARENT);
	
	player.current_frame = player.next_frame = sprite_2_a;
	playerB.current_frame = playerB.next_frame = Bsprite_2_a;
	
}

void init_player () {
	// Inicializa player con los valores iniciales
	// (de ahi lo de inicializar).
	player.x = 			PLAYER_INI_X << 10;
	player.y = 			PLAYER_INI_Y << 10;
	player.frame = 		0;
	player.subframe = 	0;
}

int initialize_variables(void){
	#asm
		ld hl, _fire_duration
		ld a, 49
		rstzero: ld (hl),0 	// variables with initial value 0
		inc hl
		dec a
		jp nz, rstzero			
	#endasm
}

// Unificar los while ahorra unos 300 bytes en juegos grandes.
// Priorizar en switch los que requieran rapidez.
// Unifying while loops in this way saves around 300 bytes in big games.
// Inside the switch the first ones should contain those loops that require a faster access
int while_library(int idx_top,int library_idx){
	int x,y;
	int i=-1;
	
	while(i++<idx_top){
		switch (library_idx){
			case 5:
				aux_beams_reprinting(i);
				break;
			case 6:
				colorize_tile_helper(2+i,6);
				break;
			case 11:
				aux_beams_reprinting(i+9);
				break;
			case 17:
				if (fire_duration[i+9]>1 && fire_duration[i+9]<30){
					draw_coloured_tile(fire_coord_x_last[i+9],fire_coord_y_last[i+9],fire_type[i+9]); 
				}
				break;
			case 12:
				aux_beams_wipe(i);
				break;
			case 13:
				aux_beams_wipe(i+9);
				break;
			case 15:
				// column up
				if (asm_int_c[0]<2){
					asm_int_c[0]=2+(i*2)>=12;
				}
				draw_coloured_tile(fire_coord_x_last[asm_int_d[0]],2+(i*2),asm_int_c[0]); 
				break;
			case 16:
				// column down
				if (asm_int_c[0]<2){
					asm_int_c[0]=20-(i*2)>=12;
				}
				draw_coloured_tile(fire_coord_x_last[asm_int_d[0]],20-(i*2),asm_int_c[0]); 
				break;
			case 1:
				x=0;
				if (trophys_status[i]>0){
					x=33;
				}else if (i<29 && show_how_to_get_trophy[i]==1){
					x=32;
				}
				if (x>0){
					draw_coloured_tile(1+(3*(i%10))+((i/10)%2),7+(3*(i/10)),x);
				}
				break;
			case 2:
				aux_unlocker(i);
				all_unlocked=all_unlocked+trophys_status[i];
				break;
			case 3:
				gpit4=i*2;
				// default tiles begin
				gpit3=0; // default
				if (i>5){
					gpit3=1;
				}
				// default tiles end
				while_library(15,4);
				break;
			case 4:
				if (gpit4==22){
					gpit3=2+(rand()%4);					
				}
				if (gpit4==0){
					gpit3=2+(rand()%4);
				}
				draw_coloured_tile (i*2,gpit4,gpit3);
				break;
			case 7:
				asm_int_d[0]=1750-(i*30);
				#asm
					ld a,10
					call _play_frequence
				#endasm
				break;
			case 8:
				word4[i]=word4[i+1];
				break;
			case 9:
				word5[i]=word5[i+1];
				break;
			case 10:
				word8[i]=word8[i+1];
				break;
			case 14:
				word10[i]=word10[i+1];
				break;
			case 19:
				while_library(10,20);
				break;
			case 20:
				break;
			case 21:
				sp_TileArray (i, allpurposepuntero);
				allpurposepuntero += 8;
				break;
		}
	}
}	

int aux_unlocker(int i){
	if (trophys_status[i]==1){
		unlocked_trophy=1;
		trophys_status[i]=2;
		aux_peb5();
		print_str(0,6,6,texts_things_reduced[7]);
		print_str(0,7,6,texts_interact[0]);
		print_str(0,8,6,texts_interact[0]);
		print_str(0,8,7+64,action_texts[0]);
		print_str(0,9,6,texts_interact[0]);
		print_str(0,10,6,texts_interact[0]);
		print_str(0,10,4+64,trophys_names_texts[i*2]);
		print_str(0,11,6,texts_interact[0]);
		print_str(0,12,6,texts_interact[0]);
		print_str(0,12,5+64,trophys_names_texts[(i*2)+1]);
		print_str(0,13,6,texts_interact[0]);
		print_str(0,14,6,texts_interact[0]);
		print_str(0,14,7+64,action_texts[1]);
		print_str(0,15,6,texts_interact[0]);
		print_str(0,16,6,texts_things_reduced[7]);
		sp_UpdateNow();
		while (!sp_GetKey ()) {
		}
		aux_peb5();
	}
}
							
int aux_beams_wipe(int i){
	if (fire_duration[i]>1){
		if (fire_coord_x_last[i]!=255){
			// wipe trace of item in former step
			aux_draw_coloured_tile_beams(i,fire_coord_y_last[i]/12);// tile 0 or tile 1
		}
	}
}

int aux_beams_reprinting(int i){
	if (fire_duration[i]>1){
		fire_coord_x_last[i]=fire_coord_x[i];
		fire_coord_y_last[i]=fire_coord_y[i];
		--fire_duration[i];
		aux_upd_beams(i); // update movement of the beam
		aux_draw_coloured_tile_beams(i,fire_type[i]);
	}
	if (fire_duration[i]==1){
		aux_draw_coloured_tile_beams(i,fire_coord_y_last[i]/12);// tile 0 or tile 1
		fire_duration[i]=0;
	}
}
					
int aux_reset_fire_coords(int i){
	fire_coord_x_last[i]=255;
	fire_coord_y_last[i]=255;
}
	
int step (void) { // 18 bytes
	#asm
		ld a, 16
		out (254), a
		nop
		nop
		nop
		nop
		nop
		nop
		nop
		nop
		nop
		xor 16
		out (254), a
		ret
	#endasm	
}
					
int rand (void) {
	
	unsigned char res;
	
	#asm // 46 bytes
		.rand16
			ld	hl, _seed
			ld	a, (hl)
			ld	e, a
			inc	hl
			ld	a, (hl)
			ld	d, a
			
			;; Ahora DE = [SEED]
						
			ld	a,	d
			ld	h,	e
			ld	l,	253
			or	a
			sbc	hl,	de
			sbc	a, 	0
			sbc	hl,	de
			ld	d, 	0
			sbc	a, 	d
			ld	e,	a
			sbc	hl,	de
			jr	nc,	nextrand
			inc	hl
		.nextrand
			ld	d,	h
			ld	e,	l
			ld	hl, _seed
			ld	a,	e
			ld	(hl), a
			inc	hl
			ld	a,	d
			ld	(hl), a
			
			;; Ahora [SEED] = HL
		
			ld 	hl, _asm_int
			ld	a,	e	
			ld	(hl), a
			inc	hl
			ld	a,	d
			ld	(hl), a
			
			;; Ahora [ASM_INT] = HL
	#endasm
	
	res = asm_int [0];	
	return res;
	
}

int read_keys(void){
	gpit = (joyfunc) (&keys); // Leemos del teclado
}

int espera_pasiva (int espera) {
	while_library(espera,19);
}
