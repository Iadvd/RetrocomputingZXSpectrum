// mainloop.h

// Churrera copyleft 2011 by The Mojon Twins.

void do_game (void) {
	unsigned int j;
	
	// splib2 initialization
	sp_Initialize (7, 0);
	sp_AddMemory(0, 40, 14, AD_FREE); // reserva 40 bloques de 14 bytes a partir de dir 61952
	
	// Define keys and default controls
	keys.fire  = sp_LookupKey(' ');
	keys.up  = sp_LookupKey('t');
	keys.down  = sp_LookupKey('r');
	keys.left  = sp_LookupKey('d');
	
	init_player ();
	Setup_Tileset_Sprites();
	
	// Music + color rotation effect begin
	#asm
		call musicstart
		call _auxy_rotate
		ld a,90
		ld (_asm_int_b),a	// preparing the color rotation
	#endasm
	while (!sp_GetKey ()) {
		seed[0]=(seed[0]+1)%1000;
		auxy_rotate_2();
		#asm 
			jp nz, no_calling_rotate_palette_2
				ld a,73-32
				ld (_asm_int_c),a //HI 22528+(32*18)+9 // 23113 // 1011010 01001001 // 90 73
				ld a,5
				call rotate_palette				
				ld a,79-32
				ld (_asm_int_c),a //90 79
#ifndef SPANISH_VER				
				ld a,1
				call rotate_palette
				ld a,81-32
				ld (_asm_int_c),a //90 81
				ld a,3
				call rotate_palette
#else
				ld a,5
				call rotate_palette
#endif
			no_calling_rotate_palette_2:
		#endasm
	}
	// Music + color rotation effect end
	
	aux_peb5();
	
	
	while (1) {
		
		#asm
			di
		#endasm
		
		initialize_variables();
		
		blackout_area();
		sp_UpdateNow();
		
		joyfunc = sp_JoyKeyboard;
		playing=0;
		who=0;
		aux_unlock();
			
		playing=1;
		
		main_looper=0;
		j=0;
		trophy_sweetdreams=0;
		
		while (playing){
			
			read_keys();	
			if ((gpit & sp_LEFT)==0){
				easy_game=(easy_game+1)%2;
				aux_peb4();
			}
			print_str(30,0,64+40+2-easy_game,texts_things_reduced[14+easy_game]);
			sp_UpdateNow();
				
			read_keys();	
			if ((gpit & sp_UP)==0){
				
				aux_peb5();
				
				// TROPHY ROOM
				trophy_sweetdreams=0;
				vengo_de_juego=0;
				
				// win a trophy END
				trophy_aladin++;
				if (trophy_aladin==20){
					set_trophy(29);
				}
				// win a trophy END
				
				current_trophy=0;
				who=1;
				saca_a_todo_el_mundo_de_aqui();
				prepare_screen((unsigned int) (w_title));
				gpit2=0;
				gpit3=1;
				show_texts_trophy();
				j=0;
				trophy_ecstasy=0;
				while(gpit2==0){
					#asm
						call nextnote
					#endasm
					if (j%2==0){
						efectillo_brillo();
						gpit3=(gpit3+1)%5;
						aux_print_str_ct();
						sp_UpdateNow();
					}
					j++;
					
					if (rand()%5==0){
						#asm
							call efectillo_brillo_banner
						#endasm
					}
					read_keys();
					if ((gpit & sp_FIRE)==0){
						// advance
						gpit3=0;
						aux_print_str_ct();
						current_trophy=(current_trophy+1)%40;
						show_texts_trophy();
					}
					if ((gpit & sp_DOWN)==0){
						gpit2=1;
						aux_peb5();
					}
					
					sp_UpdateNow();
					
					// win a trophy BEGIN
					trophy_ecstasy++;
					if (trophy_ecstasy==1100){
						// 370 cycles = aprox. 1 minute in this screen
						// so this is like being 3 minutes at the trophy room
						set_trophy(39);
					}
					// win a trophy END
				}
				who=0;
				aux_unlock();
				rmc(1);
				sp_UpdateNow();
			} 
				
			if (who==0){
				
				if (main_looper%70==0){
					rmc(j%2); // Render main character
					j++;
				}
				
				// MAIN MENU
				do_your_things();
				sp_UpdateNow();
				
				main_looper++;
				
				read_keys();
				if ((gpit & sp_FIRE)==0){
					// GAME
					++vengo_de_juego;
					accumulated_invincibility=0;
					trophy_patoaventuras=0;
					current_game_hearts=0;
					current_game_cakes=0;
					current_game_coins=0;
					current_game_sppecys=0;
					time_passed_after_invincibility=0;
					podometer=0;
					ingame_looper=0;
					up=0;
					press_fire=0;
					j=player.x;
					#asm
						ld a,7
						call peta_el_beeper
						ld a,6
						call peta_el_beeper
					#endasm		
					while (player.x<14784){
						player.x = player.x+64;
						if (ingame_looper%10<5){
							rmc(0);
						}else{
							rmc(1);
							step();
						}
						do_your_things();
						ingame_looper++;
						main_looper++;
					}
					saca_a_todo_el_mundo_de_aqui();
					who=2;
					prepare_screen((unsigned int) (w_title));
					player.x=j-2048;
					j=0;
					while (j==0){
						if (ingame_looper%28<14){ // Clive's movement
							rmc(0);
						}else{
							rmc(1);
						}
						if (ingame_looper%(accumulated_invincibility>0?4:7)==0){
							while_library(7,12); // wipe items
							if( ingame_looper%2==0){
								while_library(4,13); // wipe clouds and ducks
								while_library(4,11);// update clouds and ducks (change pos)
							}else{
								while_library(4,17);// update clouds and ducks (same pos)
							}
							while_library(7,5); // update items
							if (ingame_looper%28==0){
								new_beam(-1,7); // new item from right to left 0..7
								if (ingame_looper%3==0){
									new_beam(7,13); // new clouds and ducks
								}
							}
							if (make_the_c5_sound==1){
								// C5
								sp_UpdateNow();
								gpit3=23;
								while_library(40,7);
								make_the_c5_sound=0;
							}
						}
						bump_clive=manage_beams(-1,13); // detect next hit in gpit2 is z
						switch (bump_clive){
							case 2:
								// mac
								++accumulated_bumped_by_mac;
								j=1;
								break;
							case 3:
								// ibm
								++accumulated_bumped_by_ibm;
								j=1;
								break;
							case 4:
								// clone 1
								++accumulated_bumped_by_clone;
								j=1;
								break;
							case 5:
								++accumulated_bumped_by_clone;
								j=1;
								// clone 2
								break;
							case 6:
								// heart
								aux_increaser(&accumulated_hearts);
								aux_increaser(&current_game_hearts);
								break;
							case 7:
								// cake
								aux_increaser(&accumulated_cakes);
								aux_increaser(&current_game_cakes);
								break;
							case 8:
								// coin
								aux_increaser(&accumulated_coins);
								aux_increaser(&current_game_coins);
								break;
							case 9:
								// speccy
								aux_increaser(&accumulated_sppecys);
								aux_increaser(&current_game_sppecys);
								break;
							case 10:
								// invincibility
								set_trophy(10);
								accumulated_invincibility=200;
								make_the_c5_sound=1;
								break;
							default:
								if (bump_clive<33){
									break;
								}
								// words
								// add bump_clive-32 to words
								// move left if necessary and word pointer+1
								gpit=bump_clive-32;
								if (wp4<4){
									word4[wp4]=gpit;
									wp4++;
								}else{
									while_library(2,8);
									word4[3]=gpit;
								}
								if (wp5<5){
									word5[wp5]=gpit;
									wp5++;
								}else{
									while_library(3,9);
									word5[4]=gpit;
								}
								if (wp8<8){
									word8[wp8]=gpit;
									wp8++;
								}else{
									while_library(7,10);
									word8[7]=gpit;
								}
								if (wp10<10){
									word10[wp10]=gpit;
									wp10++;
								}else{
									while_library(9,14);
									word10[9]=gpit;
								}
								
								// compare with different words and give trophy
								if (all_same(word4,moon_text,3)){
									set_trophy(16);
								}
								
								if (all_same(word4,zork_text,3)){
									set_trophy(15);
								}
								if (all_same(word5,iadvd_text,4)){
									set_trophy(37);
								}
								if (all_same(word8,sirclive_text,7)){
									set_trophy(8);
								}
								if (all_same(word8,molomazo_text,7)){
									set_trophy(38);
								}
								/* test
								print_number1(10,20,2,(int)word10[0]);
								print_number1(13,20,2,(int)word10[1]);
								print_number1(16,20,2,(int)word10[2]);
								print_number1(19,20,2,(int)word10[3]);
								print_number1(22,20,2,(int)word10[4]);
								print_number1(25,20,2,(int)word10[5]);
								print_number1(28,20,2,(int)word10[6]);
								print_number1(31,20,2,(int)word10[7]);
								
								print_number1(10,21,3,(int)manic_text[0]);
								print_number1(13,21,3,(int)manic_text[1]);
								print_number1(16,21,3,(int)manic_text[2]);
								print_number1(19,21,3,(int)manic_text[3]);
								print_number1(22,21,3,(int)manic_text[4]);
								print_number1(25,21,3,(int)manic_text[5]);
								print_number1(28,21,3,(int)manic_text[6]);
								print_number1(31,21,3,(int)manic_text[7]);
								*/
								if (all_same(word10,manic_text,9)){
									set_trophy(25);
								}
								break;
						}
								
						if (accumulated_invincibility>0){
							--accumulated_invincibility;
							if (accumulated_invincibility==0){
								time_passed_after_invincibility=100;
								gpit3=23;
								while_library(40,7);
							}							
						}
						print_number1(12,0,69,current_game_hearts);
						print_number1(18,0,69,current_game_coins);
						print_number1(24,0,69,current_game_cakes);
						print_number1(30,0,69,current_game_sppecys);
						if (ingame_looper%10==0){
							if (accumulated_podometer<65000){
								++accumulated_podometer;
							}
							if (podometer<65000){
								++podometer;
							}
							print_number1(6,0,69,podometer); // podometer
						}
						sp_UpdateNow();
						read_keys();
						if ((gpit & sp_FIRE)==0){
							if (up==0){
								if (press_fire<101){
									++press_fire;
								}
								up=1;
							}
							if (player.y>2048){
								player.y-=64;
							}
						}else if (player.y<10240){
							if (up==1){
								up=0;
							}
							player.y+=64;
						}
						if (ingame_looper<65520){
							ingame_looper++;
						}else{
							ingame_looper=1;
						}
						if (time_passed_after_invincibility>0){
							--time_passed_after_invincibility;
						}
					}
					if(record_podometer<podometer){
						record_podometer=podometer;
					}
					rmc(2);
					rmc(2);
					sp_UpdateNow();
					espera_pasiva(ESPERA_PASIVA);
					gpit3=20;
					while_library(40,7); // freq. sound
					// avoid garbage in sprite
					aux_draw_coloured_tile_beams(gpit2,fire_coord_y_last[gpit2]/12);
					rmc(2);
					sp_UpdateNow();
					saca_a_todo_el_mundo_de_aqui();
					init_player ();
					initialize_variables();
					
					// win a trophy BEGIN
					if (current_game_hearts>9 && current_game_coins==0){
						set_trophy(1);
					}
					if (accumulated_hearts>50){
						set_trophy(2);
					}
					if (current_game_coins>9 && current_game_hearts==0){
						set_trophy(3);
					}
					if (accumulated_coins>50){
						set_trophy(4);
					}
					if (accumulated_cakes>0){
						set_trophy(17);
					}
					if (current_game_cakes==80){
						set_trophy(18);
					}
					if (accumulated_cakes>100){
						set_trophy(20);
					}
					if (accumulated_sppecys>0){
						set_trophy(23);						
					}
					if (accumulated_sppecys>100){
						set_trophy(24);
					}
					if (current_game_cakes+current_game_coins+current_game_hearts+current_game_sppecys>100){
						set_trophy(26);
					}
					if (accumulated_cakes+accumulated_coins+accumulated_hearts+accumulated_sppecys>300){
						set_trophy(27);
					}
					if (current_game_cakes==0 && current_game_sppecys>10){
						set_trophy(28);
					}
					if (bump_clive==2){
						set_trophy(7);
						trophy_gana_internet=trophy_gana_internet|1;
					}
					if (bump_clive==3){
						set_trophy(6);
						trophy_gana_internet=trophy_gana_internet|2;
					}
					if (bump_clive==4||bump_clive==5){
						set_trophy(12);
						trophy_gana_internet=trophy_gana_internet|(bump_clive==5?4:8);
					}
					if (trophy_gana_internet==15){
						set_trophy(22);
					}
					if (podometer>100 && current_game_coins==0 && tipo_juego==0){
						set_trophy(11);
					}
					if (podometer>100 && current_game_cakes==0 && tipo_juego==0){
						set_trophy(19);
					}
					if (podometer>100){
						set_trophy(13);
					}
					if (podometer<30){
						++trophy_dejalo;
						if (trophy_dejalo==10){
							set_trophy(9);
						}
					}
					else{
						trophy_dejalo=0;
					}
					if (accumulated_podometer>1000){
						set_trophy(14);
					}
					if (vengo_de_juego==10){
						set_trophy(30);
					}
					if (press_fire==0){
						set_trophy(34);
					}
					if (press_fire==101){
						set_trophy(35);
					}
					if (trophy_patoaventuras>10){
						set_trophy(21);
					}
					if (time_passed_after_invincibility>0){
						set_trophy(36);
					}
					// win a trophy END
					
					tipo_juego=(tipo_juego+1)%2;
					
					if (tipo_juego==1){
						switch (tipo_juego_word){
							case 0:
								words_pool=moon_text;
								tipo_juego_word_pointer=4;
								break;
							case 1:
								words_pool=zork_text;
								tipo_juego_word_pointer=4;
								break;
							case 2:
								words_pool=iadvd_text;
								tipo_juego_word_pointer=5;
								break;
							case 3:
								words_pool=sirclive_text;
								tipo_juego_word_pointer=8;
								break;
							case 4:
								words_pool=molomazo_text;
								tipo_juego_word_pointer=8;
								break;
							case 5:
								words_pool=manic_text;
								tipo_juego_word_pointer=10;
								break;
						}
						tipo_juego_word=(tipo_juego_word+1)%6;
					}
					trophy_sweetdreams=0;
					unlocked_trophy=0;
					who=0;
					aux_unlock();
					rmc(2);
					sp_UpdateNow();
				}
								
				// win a trophy BEGIN
				if (trophy_sweetdreams<10000){
					trophy_sweetdreams++;
					if (trophy_sweetdreams==10000){
						// 500 cycles = aprox. 2 minutes in this screen
						// so this is like being 2 minutes at the trophy room
						if (trophys_status[5]==0){
							trophys_status[5]=1;
							unlocked_trophy=1;
							aux_unlock();
						}
						dreampos1=0;
						dreampos2=2;
						// win a trophy BEGIN
						trophy_tsetse++;
						if (trophy_tsetse==4){
							if (trophys_status[31]==0){
								trophys_status[31]=1;
								unlocked_trophy=1;
								aux_unlock();
							}
						}
						// win a trophy END
						
					}
				}
				// win a trophy END
				
			}	
			
		}
		
	}
			
}

int aux_print_str_ct(void){
	print_str(1+(3*(current_trophy%10))+((current_trophy/10)%2),6+(3*(current_trophy/10)),gpit3,texts_things_reduced[5]); //&
	print_str(1+(3*(current_trophy%10))+((current_trophy/10)%2),9+(3*(current_trophy/10)),gpit3,texts_things_reduced[5]); //&							
}					
						
int aux_increaser(unsigned int * counter){
	if (*counter<9999){
		*counter=(*counter)+1;
	}
}
int all_same(unsigned char *w,unsigned char *t,unsigned char q){
	int i=-1;
	int eq=(1==1);
	while(i++<q){
		eq=eq&&(*(w+i)==*(t+i));
	}
	return eq;
}
									
int set_trophy(int which_trophy){
	if (trophys_status[which_trophy]==0){
		trophys_status[which_trophy]=1;
	}
}
						
int do_your_things(void){
	switch(rand()%48){
		case 0:
			// Left duck left
			draw_coloured_tile(16,14,38);
			break;
		case 1:
			// Left Duck right
			draw_coloured_tile(16,14,39);
			break;
		case 2:
			// Right Duck left
			draw_coloured_tile(28,15,40);
			break;
		case 3:
			// Right Duck right
			draw_coloured_tile(28,15,41);
			break;
		case 4:
			// Zork left
			draw_coloured_tile(19,14,42);
			draw_coloured_tile(21,14,43);
			break;
		case 5:
			// Zork right
			draw_coloured_tile(19,14,44);
			draw_coloured_tile(21,14,45);
			break;
		case 6:
			// Moon left
			if (trophy_sweetdreams!=10000){
				draw_coloured_tile(23,14,46);
			}
			break;
		case 7:
			// Moon right
			if (trophy_sweetdreams!=10000){
				draw_coloured_tile(23,14,47);
			}
			break;
		case 8:
			#asm
				call efectillo_brillo_banner
			#endasm
			break;
		case 9:
			if (rand()%10==0){
				#asm
				ld a,0
				call peta_el_beeper
				#endasm	
			}
			break;
		case 10:
			if (rand()%10==0){
				#asm
				ld a,1
				call peta_el_beeper
				#endasm	
			}
			break;
		case 11:
			// Barrendero izda
			if (trophy_sweetdreams!=10000){
				if (rand()%4==0){
					draw_coloured_tile(12,14,34);
					draw_coloured_tile(12,16,35);
				}								
			}
			break;
		case 12:
			// Barrendero decha
			if (trophy_sweetdreams!=10000){
				if (rand()%4==0){
					draw_coloured_tile(12,14,36);
					draw_coloured_tile(12,16,37);
				}								
			}
			break;
		case 13:
			if (rand()%2==0){
				#asm
					call erotulos
				#endasm
			}
			break;
	}
	
	if (trophy_sweetdreams==10000){
		// Moon sleeping
		draw_coloured_tile(23,14,31);
		// Barrendero durmiendo
		draw_coloured_tile(12,14,30);
		draw_coloured_tile(12,16,35);
		// Vinyetas ZZZ
		if (main_looper%8==0){
			draw_coloured_tile(25,14,26+dreampos1);
			draw_coloured_tile(14,14,26+dreampos2);
			dreampos1=(dreampos1+1)%4;
			dreampos2=(dreampos2+1)%4;
		}
	}
	
	if (main_looper%100==0){
		efectillo_brillo();
	}
	
	if (all_unlocked==80||all_unlocked==160){
		draw_coloured_tile(20,6,33);
	}
	
	sp_UpdateNow();
	
}

int aux_unlock(void){
	if (unlocked_trophy==0){
		prepare_screen((unsigned int) (s_title));
	}
	unlocked_trophy=0;
	if (all_unlocked!=80){
		all_unlocked=0;
	}
	while_library(39,2);//unlock_trophys();
	if (trophys_status[41]==0 && all_unlocked==80){
		trophys_status[41]=1;
		aux_unlocker(41);
	}
	if (unlocked_trophy==1){
		// check if all unlocked
		prepare_screen((unsigned int) (s_title));		
		unlocked_trophy=0;
	}
}

int show_texts_trophy(void){
	aux_stt1(6);
	aux_stt1(9);
	aux_stt2(texts_interact[0],texts_interact[0]);
	if (trophys_status[current_trophy]>0){
		aux_stt2(trophys_names_texts[current_trophy*2],trophys_names_texts[(current_trophy*2)+1]);
	}else{
		aux_stt2(trophys_names_texts[80],trophys_names_texts[81]);
		if (current_trophy<29){
			if (show_how_to_get_trophy[current_trophy]==1){
				// current_trophy is the leader in the upper conditions
				print_str(0,21,5+64,trophys_names_texts[(current_trophy*2)+1]);
			}
		}
	}
	sp_UpdateNow();
}				

int aux_stt1(int i){
	print_str(1+(3*(current_trophy%10))+((current_trophy/10)%2),i+(3*(current_trophy/10)),gpit3,texts_things_reduced[5]); //&
}

int aux_stt2(char * s1, char * s2){
	print_str(0,19,4+64,s1);
	print_str(0,21,5+64,s2);
}
					
int efectillo_brillo(void){
	#asm
		ld hl,23269
		call efectillo
		ld hl,23274
		call efectillo
		jp cont_looper
		.efectillo
			ld a,(hl)
			cp 67
			jp z, towhite
			ld (hl),67
			ret
			.towhite
				ld (hl),66
			ret
		.cont_looper
	#endasm	
}

int efectillo_publi(void){
	#asm
		ld hl,22801 //22528+273
		call change_bright
		ld hl,22833 //22528+273+32
		call change_bright
		ld hl,22865 //22528+273+64
		call change_bright
		ld hl,22897 //22528+273+96
		call change_bright
		ld hl,22805 
		call change_bright
		ld hl,22837 
		call change_bright
		ld hl,22869 
		call change_bright
		ld hl,22901 
		call change_bright
		ld hl,22809 
		call change_bright
		ld hl,22841 
		call change_bright
		ld hl,22873 
		call change_bright
		ld hl,22904 
		call change_bright
	#endasm	
}

int auxy_rotate(void){
	#asm
		ld a,7
		ld (_col),a
		ld a,0
		ld (_rotate_colors_tempo),a
	#endasm
}

int auxy_rotate_2(void){
	#asm
		ld a,(_rotate_colors_tempo)
		inc a
		ld (_rotate_colors_tempo),a
		and 5
		cp 5
	#endasm
}

int prepare_screen(unsigned int screen) {
	int i,j;
	
	blackout_area();
	sp_UpdateNow();
	
	if (who<2){
		// the following made instead of unpack (screen, 16384);
		// we use this memory buffer below instead of unpacking the main menu
		// directly to the screen memory address because when we unpack 
		// the main menu directly to screen memory address, 
		// specially when the we come from the initial loading screen,
		// we observe blinkings (not enough time to put the whole screen on time)
		// curiously, unpaking the main menu first in an internal buffer and then copying
		// the buffer to the screen memory avoids the blinkings... 
		// I guess is somehow a little bit faster probably due to the 
		// position of the halt command at our ldir routine
		// unpack (screen, screen_buffer);
		// calling directly the unpack asm routine
		ram_address [0] = screen;
		ram_destination [0] = (unsigned int)(screen_buffer);
		#asm	
			ld a,0
			ld (23693),a 
			call 3503 
			ld hl, (_ram_address)
			ld de, (_ram_destination)
			call depack
			call move_buffer_to_screen
		#endasm	
	}
	switch (who){
		case 0:
			// MAIN MENU
			print_number1(10,0,69,accumulated_hearts);
			print_number1(16,0,69,accumulated_coins);
			print_number1(22,0,69,accumulated_cakes);
			print_number1(28,0,69,accumulated_sppecys);
			print_str (8, 18, 4, texts_interact[1]);
			print_str (8, 19, 4, texts_interact[1]);
			print_str (8, 20, 4, texts_interact[1]);
			print_str (8, 21, 4, texts_interact[1]);
			print_str (8, 22, 32, "                       ");
			print_number1(26,23,70,record_podometer);
			break;
		case 1:
			// TROPHY ROOM
			while_library(39,1);
			break;
		case 2:
			gpit2=0;
			while_library(3,6);
			while_library(11,3);
			
			print_str (8, 0, 66, texts_things_reduced[1]);
			print_str (9, 0, 69, "0000");
			
			print_str (14, 0, 70, texts_things_reduced[0]);
			print_str (15, 0, 69, "0000");
			
			print_str (20, 0, 96, texts_things_reduced[2]);
			print_str (21, 0, 69, "0000");
			
			print_str (26, 0, 112, texts_things_reduced[8]);
			print_str (27, 0, 69, "0000");
			
			print_str (1, 0, 5,"P");
			print_str (2, 0, 69, "00000");
			
			break;
	}
}

// BEAMS ENGINE BEGIN
int new_beam(int z, int zend){
	int x,y;
	while(z++<zend){
		if (fire_duration[z]==0){
			aux_reset_fire_coords(z);
			fire_duration[z]=32;
			fire_coord_x[z]=30;
			if (zend!=13){
				if (creation_column==0){
					fire_type[z]=2+(rand()%4);
				}else{
					fire_type[z]=6+(rand()%4);
					if (rand()%30==0){
						fire_type[z]=10;
					}
					//fire_type[z]=10; //test C5
				}
				creation_column=(creation_column+1)%4;
				// default: items game
				if (tipo_juego==1 && fire_type[z]>5){
					// words game
					fire_type[z]=words_pool[word_pool_pointer]+32;
					word_pool_pointer=(word_pool_pointer+1)%tipo_juego_word_pointer;//14;
				}
				fire_coord_y[z]=2+((rand()%10)*2);
				while ((fire_coord_y[z]>8)&&(fire_coord_y[z]<14)&&(fire_type[z]<6)){
					fire_coord_y[z]=2+((rand()%10)*2);
				}
				#asm
					ld a,1
					call peta_el_beeper
				#endasm	
			}else{
				// clouds and ducks parallax
				fire_type[z]=z;
				fire_coord_y[z]=6; // 13 is default
				switch(z){
					case 9:
						// a duck
						fire_type[z]=14;
						fire_coord_y[z]=12;
						break;
					case 10:
						// a duck
						fire_type[z]=14;
						fire_coord_y[z]=16;
						break;
					case 11:
						// a cloud
						fire_coord_y[z]=4;
						break;
					case 12:
						// a cloud
						fire_coord_y[z]=8;
						break;
				}
			}
			break;
		}
	}
}
							
int aux_upd_beams(int z){
	if (z<9 || z>13){
		--fire_coord_x[z];
	}else if(ingame_looper%(2)==0){
		// very simple clouds parallax
		--fire_coord_x[z];
	}
}

int manage_beams(int z,int zend){
	int x,y,i;
	int cond1,cond2,cond3;
	int hit=0;
	while(z++<zend){
		if (fire_duration[z]!=0){
			if (fire_type[z]>10 && fire_type[z]<14){
				continue; //clouds...
			}
			x=PLAYER_INI_X-fire_coord_x[z];
			if (x<0){
				// the item is ahead...
				x=x*-1;
			}else{//else if (fire_type[z]<=5){
				// the item is behind...
				x=x-2;
			}
			// this y is only for items not for bumping computers
			y=player.y-(fire_coord_y[z]<<9); //pixel perfect
			if (y<0){
				y=y*-1; // negatives are 0 and -1 only
			}else{
				// little trick
				if (y<=(3<<9)){
					y=1<<9; // positives are 0,1,2,3 fixed 1 so the big conditions below is simpler
				}
			}
			y=y>>9;
			// pixel perfect
			cond1=(fire_coord_y[z]>10)&&((player.y+(2<<9)>=(fire_coord_y[z]<<9))||(player.y-(2<<9)<=((fire_coord_y[z]-(6+(easy_game*2)))<<9))); // (8/2)=4 empty tiles between up/down columns
			cond2=(fire_coord_y[z]<10)&&((player.y-(2<<9)<=(fire_coord_y[z]+2<<9))||(player.y+(2<<9)>=((fire_coord_y[z]+(8+(easy_game*2)))<<9)));
			cond3=((x<2)&&((y<=1)&&fire_type[z]>5)||((x<1)&&(fire_type[z]<6)&&(cond1||cond2)));
			if(cond3)
			{
				if (fire_duration[z]!=1){
					if (fire_type[z]<6){
						if (accumulated_invincibility==0){
							// bump!
							#asm
								ld a,3
								call peta_el_beeper
							#endasm	
							if ((player.y>>9)<12){
								++trophy_allaenloalto;
								if (trophy_allaenloalto==5){
									set_trophy(32);
								}
							}
							if ((player.y>>9)>11){
								++trophy_bajafidelidad;
								if (trophy_bajafidelidad==5){
									set_trophy(33);
								}
							}
						}						
					}else{
						switch(fire_type[z]){
							case 6:
							case 7:
								aux_peb5();
								break;
							case 8:
							case 9:
								aux_peb4();
								break;
							//case 10: // not here...
							//	break;
							case 14:
								++trophy_patoaventuras;
								break;
							default:
								//words
								#asm
									ld a,2
									call peta_el_beeper
								#endasm	
								break;
						}		
					}
					gpit2=z;
					hit=fire_type[z];
					if (hit<6 && accumulated_invincibility>0){
						hit=0;
					}else if(fire_type[z]!=14){
						fire_duration[z]=1; // beam dissappears
						return hit;
					}
				}
				
			}

		}
	}
	return hit;
}
	
int aux_draw_coloured_tile_beams(int z, int which_tile){
	int wt1=0,wt2=0,color=fire_coord_y_last[z]<12?69:5;
	if (which_tile<33){
		// tiles
		if (which_tile>5){
			if (which_tile==6){
				colorize_tile_helper(which_tile,fire_coord_y_last[z]<12?85:21);
			}else if (which_tile<11){
				// default
				colorize_tile_helper(which_tile,color);
			}
		}
		if (which_tile<6 && fire_type[z]>1 && fire_type[z]<6){
			asm_int_c[0]=which_tile;
			asm_int_d[0]=z;
			if (fire_coord_y_last[z]<12){
				//2,4,6,8,10=1,2,3,4,5
				wt2=4+easy_game;
			}else{
				//12,14,16,18,20=6,7,8,9,10
				wt1=4+easy_game;
			}
			while_library((fire_coord_y_last[z]/2)-1-wt1,15);
			while_library(10-(fire_coord_y_last[z]/2)-wt2,16);
			
		}else{
			draw_coloured_tile(fire_coord_x_last[z],fire_coord_y_last[z],which_tile); 
		}
		
	}else{
		// words
		print_str(fire_coord_x_last[z],fire_coord_y_last[z],color,texts_things_reduced[3]);
		print_str(fire_coord_x_last[z]+1,fire_coord_y_last[z],color,texts_things_reduced[3]);
		print_str(fire_coord_x_last[z],fire_coord_y_last[z]+1,color,texts_things_reduced[3]);
		print_str(fire_coord_x_last[z]+1,fire_coord_y_last[z]+1,fire_coord_y_last[z]<12?69+1:5+1,(unsigned char *)(&which_tile));
	}
}
					
// BEAMS ENGINE END

