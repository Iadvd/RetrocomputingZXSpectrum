// Sprites.h
// Generado por SprCnv de la Churrera
// Copyleft 2010 The Mojon Twins
 
extern unsigned char Bsprite_1_a []; 
extern unsigned char Bsprite_1_b []; 
extern unsigned char Bsprite_1_c []; 
extern unsigned char Bsprite_2_a []; 
extern unsigned char Bsprite_2_b []; 
extern unsigned char Bsprite_2_c []; 
extern unsigned char Bsprite_3_a []; 
extern unsigned char Bsprite_3_b []; 
extern unsigned char Bsprite_3_c []; 
 
#asm
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._Bsprite_1_a
        defb 0, 248
        defb 3, 227
        defb 15, 143
        defb 13, 13
        defb 26, 26
        defb 29, 29
        defb 63, 63
        defb 63, 63
        defb 60, 60
        defb 27, 27
        defb 66, 66
        defb 106, 106
        defb 107, 107
        defb 76, 76
        defb 15, 143
        defb 7, 199
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._Bsprite_1_b
        defb 0, 15
        defb 240, 247
        defb 240, 243
        defb 248, 251
        defb 220, 221
        defb 172, 173
        defb 220, 221
        defb 252, 253
        defb 100, 101
        defb 152, 153
        defb 244, 245
        defb 148, 149
        defb 104, 107
        defb 228, 229
        defb 236, 237
        defb 140, 141
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._Bsprite_1_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._Bsprite_2_a
        defb 0, 248
        defb 3, 227
        defb 15, 143
        defb 15, 15
        defb 31, 31
        defb 28, 28
        defb 59, 59
        defb 63, 63
        defb 60, 60
        defb 27, 27
        defb 66, 66
        defb 106, 106
        defb 107, 107
        defb 76, 76
        defb 15, 143
        defb 7, 199
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._Bsprite_2_b
        defb 0, 15
        defb 240, 247
        defb 240, 243
        defb 248, 251
        defb 252, 253
        defb 100, 101
        defb 152, 153
        defb 252, 253
        defb 100, 101
        defb 152, 153
        defb 244, 245
        defb 148, 149
        defb 104, 107
        defb 228, 229
        defb 236, 237
        defb 140, 141
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._Bsprite_2_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._Bsprite_3_a
        defb 0, 248
        defb 3, 227
        defb 15, 143
        defb 15, 15
        defb 29, 29
        defb 30, 30
        defb 46, 46
        defb 23, 23
        defb 44, 44
        defb 27, 27
        defb 66, 66
        defb 107, 107
        defb 107, 107
        defb 76, 76
        defb 15, 143
        defb 7, 199
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._Bsprite_3_b
        defb 0, 15
        defb 240, 247
        defb 240, 243
        defb 248, 251
        defb 252, 253
        defb 244, 245
        defb 108, 109
        defb 156, 157
        defb 100, 101
        defb 152, 153
        defb 100, 101
        defb 156, 157
        defb 104, 107
        defb 228, 229
        defb 236, 237
        defb 140, 141
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._Bsprite_3_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
  
#endasm
 
