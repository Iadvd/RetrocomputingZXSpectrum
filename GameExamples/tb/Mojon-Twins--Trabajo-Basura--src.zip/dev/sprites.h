// Sprites.h
// Generado por SprCnv de la Churrera
// Copyleft 2010 The Mojon Twins
 
extern unsigned char sprite_1_a []; 
extern unsigned char sprite_1_b []; 
extern unsigned char sprite_1_c []; 
extern unsigned char sprite_2_a []; 
extern unsigned char sprite_2_b []; 
extern unsigned char sprite_2_c []; 
extern unsigned char sprite_3_a []; 
extern unsigned char sprite_3_b []; 
extern unsigned char sprite_3_c []; 
extern unsigned char sprite_4_a []; 
extern unsigned char sprite_4_b []; 
extern unsigned char sprite_4_c []; 
extern unsigned char sprite_5_a []; 
extern unsigned char sprite_5_b []; 
extern unsigned char sprite_5_c []; 
extern unsigned char sprite_6_a []; 
extern unsigned char sprite_6_b []; 
extern unsigned char sprite_6_c []; 
extern unsigned char sprite_7_a []; 
extern unsigned char sprite_7_b []; 
extern unsigned char sprite_7_c []; 
extern unsigned char sprite_8_a []; 
extern unsigned char sprite_8_b []; 
extern unsigned char sprite_8_c []; 
extern unsigned char sprite_9_a []; 
extern unsigned char sprite_9_b []; 
extern unsigned char sprite_9_c []; 
extern unsigned char sprite_10_a []; 
extern unsigned char sprite_10_b []; 
extern unsigned char sprite_10_c []; 
extern unsigned char sprite_11_a []; 
extern unsigned char sprite_11_b []; 
extern unsigned char sprite_11_c []; 
extern unsigned char sprite_12_a []; 
extern unsigned char sprite_12_b []; 
extern unsigned char sprite_12_c []; 
extern unsigned char sprite_13_a []; 
extern unsigned char sprite_13_b []; 
extern unsigned char sprite_13_c []; 
extern unsigned char sprite_14_a []; 
extern unsigned char sprite_14_b []; 
extern unsigned char sprite_14_c []; 
extern unsigned char sprite_15_a []; 
extern unsigned char sprite_15_b []; 
extern unsigned char sprite_15_c []; 
extern unsigned char sprite_16_a []; 
extern unsigned char sprite_16_b []; 
extern unsigned char sprite_16_c []; 
 
#asm
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_1_a
        defb 0, 255
        defb 0, 240
        defb 0, 224
        defb 0, 192
        defb 1, 192
        defb 27, 192
        defb 27, 192
        defb 15, 224
        defb 3, 128
        defb 124, 0
        defb 103, 0
        defb 7, 144
        defb 3, 0
        defb 126, 0
        defb 124, 0
        defb 64, 3
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_1_b
        defb 0, 255
        defb 0, 31
        defb 0, 15
        defb 0, 7
        defb 80, 7
        defb 80, 7
        defb 80, 7
        defb 240, 7
        defb 224, 3
        defb 28, 1
        defb 236, 1
        defb 226, 0
        defb 214, 0
        defb 46, 0
        defb 0, 0
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_1_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_2_a
        defb 0, 240
        defb 0, 224
        defb 0, 192
        defb 1, 192
        defb 27, 192
        defb 27, 192
        defb 15, 224
        defb 3, 224
        defb 12, 192
        defb 55, 128
        defb 55, 128
        defb 54, 128
        defb 6, 128
        defb 6, 240
        defb 6, 240
        defb 7, 240
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_2_b
        defb 0, 31
        defb 0, 15
        defb 0, 7
        defb 80, 7
        defb 80, 7
        defb 80, 7
        defb 240, 7
        defb 224, 7
        defb 16, 7
        defb 232, 3
        defb 232, 3
        defb 200, 3
        defb 96, 3
        defb 96, 15
        defb 96, 15
        defb 112, 7
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_2_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_3_a
        defb 0, 255
        defb 0, 240
        defb 0, 224
        defb 0, 192
        defb 1, 192
        defb 27, 192
        defb 27, 192
        defb 15, 224
        defb 0, 224
        defb 14, 224
        defb 7, 224
        defb 8, 224
        defb 7, 192
        defb 35, 128
        defb 48, 128
        defb 32, 130
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_3_b
        defb 0, 255
        defb 0, 31
        defb 0, 15
        defb 0, 7
        defb 80, 7
        defb 80, 7
        defb 80, 7
        defb 240, 7
        defb 0, 15
        defb 160, 15
        defb 160, 15
        defb 96, 9
        defb 228, 1
        defb 252, 1
        defb 124, 1
        defb 0, 1
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_3_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_4_a
        defb 0, 240
        defb 0, 224
        defb 0, 192
        defb 1, 192
        defb 27, 192
        defb 27, 192
        defb 15, 224
        defb 3, 224
        defb 12, 128
        defb 127, 0
        defb 103, 0
        defb 7, 0
        defb 31, 192
        defb 56, 128
        defb 48, 135
        defb 0, 143
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_4_b
        defb 0, 31
        defb 0, 15
        defb 0, 7
        defb 80, 7
        defb 80, 7
        defb 80, 7
        defb 240, 7
        defb 224, 7
        defb 16, 1
        defb 254, 0
        defb 230, 0
        defb 224, 0
        defb 248, 3
        defb 28, 1
        defb 12, 225
        defb 0, 241
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_4_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_5_a
        defb 0, 255
        defb 0, 248
        defb 0, 240
        defb 0, 224
        defb 10, 224
        defb 10, 224
        defb 10, 224
        defb 15, 224
        defb 7, 192
        defb 56, 128
        defb 55, 128
        defb 71, 0
        defb 107, 0
        defb 116, 0
        defb 0, 0
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_5_b
        defb 0, 255
        defb 0, 15
        defb 0, 7
        defb 0, 3
        defb 128, 3
        defb 216, 3
        defb 216, 3
        defb 240, 7
        defb 192, 1
        defb 62, 0
        defb 230, 0
        defb 224, 9
        defb 192, 0
        defb 126, 0
        defb 62, 0
        defb 2, 192
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_5_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_6_a
        defb 0, 248
        defb 0, 240
        defb 0, 224
        defb 10, 224
        defb 10, 224
        defb 10, 224
        defb 15, 224
        defb 7, 224
        defb 8, 224
        defb 23, 192
        defb 23, 192
        defb 19, 192
        defb 6, 192
        defb 6, 240
        defb 6, 240
        defb 14, 224
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_6_b
        defb 0, 15
        defb 0, 7
        defb 0, 3
        defb 128, 3
        defb 216, 3
        defb 216, 3
        defb 240, 7
        defb 192, 7
        defb 48, 3
        defb 236, 1
        defb 236, 1
        defb 108, 1
        defb 96, 1
        defb 96, 15
        defb 96, 15
        defb 224, 15
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_6_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_7_a
        defb 0, 255
        defb 0, 248
        defb 0, 240
        defb 0, 224
        defb 10, 224
        defb 10, 224
        defb 10, 224
        defb 15, 224
        defb 0, 240
        defb 5, 240
        defb 5, 240
        defb 6, 144
        defb 39, 128
        defb 63, 128
        defb 62, 128
        defb 0, 128
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_7_b
        defb 0, 255
        defb 0, 15
        defb 0, 7
        defb 0, 3
        defb 128, 3
        defb 216, 3
        defb 216, 3
        defb 240, 7
        defb 0, 7
        defb 112, 7
        defb 224, 7
        defb 16, 7
        defb 224, 3
        defb 196, 1
        defb 12, 1
        defb 4, 65
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_7_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_8_a
        defb 0, 248
        defb 0, 240
        defb 0, 224
        defb 10, 224
        defb 10, 224
        defb 10, 224
        defb 15, 224
        defb 7, 224
        defb 8, 128
        defb 127, 0
        defb 103, 0
        defb 7, 0
        defb 31, 192
        defb 56, 128
        defb 48, 135
        defb 0, 143
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_8_b
        defb 0, 15
        defb 0, 7
        defb 0, 3
        defb 128, 3
        defb 216, 3
        defb 216, 3
        defb 240, 7
        defb 192, 7
        defb 48, 1
        defb 254, 0
        defb 230, 0
        defb 224, 0
        defb 248, 3
        defb 28, 1
        defb 12, 225
        defb 0, 241
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_8_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_9_a
        defb 0, 252
        defb 3, 248
        defb 5, 240
        defb 7, 240
        defb 11, 224
        defb 21, 192
        defb 42, 128
        defb 40, 128
        defb 40, 129
        defb 40, 131
        defb 40, 131
        defb 36, 129
        defb 32, 139
        defb 16, 199
        defb 8, 227
        defb 0, 247
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_9_b
        defb 0, 63
        defb 192, 31
        defb 160, 15
        defb 224, 15
        defb 208, 7
        defb 168, 3
        defb 84, 1
        defb 20, 1
        defb 20, 129
        defb 20, 193
        defb 20, 193
        defb 36, 129
        defb 4, 209
        defb 8, 227
        defb 16, 199
        defb 0, 239
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_9_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_10_a
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 252
        defb 3, 248
        defb 5, 240
        defb 7, 224
        defb 27, 128
        defb 101, 0
        defb 138, 0
        defb 144, 4
        defb 72, 3
        defb 36, 129
        defb 0, 219
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_10_b
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 63
        defb 192, 31
        defb 160, 15
        defb 224, 7
        defb 216, 1
        defb 166, 0
        defb 81, 0
        defb 9, 32
        defb 18, 192
        defb 36, 129
        defb 0, 219
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_10_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_11_a
        defb 0, 255
        defb 0, 248
        defb 0, 240
        defb 2, 240
        defb 0, 240
        defb 6, 192
        defb 20, 128
        defb 34, 0
        defb 64, 0
        defb 69, 0
        defb 68, 0
        defb 36, 0
        defb 40, 128
        defb 26, 128
        defb 16, 192
        defb 0, 239
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_11_b
        defb 0, 255
        defb 0, 63
        defb 0, 31
        defb 128, 31
        defb 0, 31
        defb 192, 7
        defb 80, 3
        defb 136, 1
        defb 4, 1
        defb 68, 1
        defb 68, 1
        defb 72, 1
        defb 40, 3
        defb 176, 3
        defb 16, 7
        defb 0, 239
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_11_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_12_a
        defb 0, 248
        defb 0, 240
        defb 2, 240
        defb 0, 0
        defb 230, 0
        defb 148, 0
        defb 130, 0
        defb 144, 0
        defb 73, 0
        defb 32, 0
        defb 26, 128
        defb 2, 192
        defb 6, 240
        defb 0, 248
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_12_b
        defb 0, 63
        defb 0, 31
        defb 128, 31
        defb 0, 0
        defb 206, 0
        defb 82, 0
        defb 130, 0
        defb 18, 0
        defb 36, 0
        defb 8, 1
        defb 176, 3
        defb 128, 7
        defb 192, 31
        defb 0, 63
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_12_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_13_a
        defb 7, 248
        defb 12, 240
        defb 24, 224
        defb 49, 192
        defb 46, 192
        defb 42, 192
        defb 46, 192
        defb 49, 192
        defb 26, 224
        defb 13, 240
        defb 26, 224
        defb 50, 192
        defb 38, 192
        defb 60, 192
        defb 25, 224
        defb 17, 224
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_13_b
        defb 240, 15
        defb 24, 7
        defb 12, 3
        defb 198, 1
        defb 58, 1
        defb 170, 1
        defb 186, 1
        defb 198, 1
        defb 44, 3
        defb 216, 7
        defb 44, 3
        defb 38, 1
        defb 50, 1
        defb 158, 1
        defb 204, 3
        defb 196, 3
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_13_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_14_a
        defb 12, 240
        defb 24, 224
        defb 49, 192
        defb 46, 192
        defb 42, 192
        defb 46, 192
        defb 49, 192
        defb 26, 224
        defb 13, 240
        defb 26, 224
        defb 18, 224
        defb 18, 224
        defb 28, 224
        defb 4, 248
        defb 12, 240
        defb 24, 224
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_14_b
        defb 24, 7
        defb 12, 3
        defb 198, 1
        defb 58, 1
        defb 170, 1
        defb 186, 1
        defb 198, 1
        defb 44, 3
        defb 216, 7
        defb 44, 3
        defb 36, 3
        defb 36, 3
        defb 156, 3
        defb 144, 15
        defb 152, 7
        defb 140, 3
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_14_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_15_a
        defb 0, 0
        defb 85, 0
        defb 43, 0
        defb 95, 0
        defb 63, 0
        defb 127, 0
        defb 63, 0
        defb 127, 0
        defb 127, 0
        defb 127, 0
        defb 127, 0
        defb 90, 0
        defb 90, 0
        defb 74, 0
        defb 127, 0
        defb 0, 0
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_15_b
        defb 0, 0
        defb 94, 0
        defb 254, 0
        defb 230, 0
        defb 230, 0
        defb 254, 0
        defb 254, 0
        defb 254, 0
        defb 254, 0
        defb 254, 0
        defb 254, 0
        defb 34, 0
        defb 118, 0
        defb 246, 0
        defb 254, 0
        defb 0, 0
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_15_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_16_a
        defb 0, 0
        defb 85, 0
        defb 43, 0
        defb 95, 0
        defb 63, 0
        defb 127, 0
        defb 63, 0
        defb 127, 0
        defb 127, 0
        defb 127, 0
        defb 127, 0
        defb 90, 0
        defb 90, 0
        defb 74, 0
        defb 127, 0
        defb 0, 0
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_16_b
        defb 0, 0
        defb 94, 0
        defb 254, 0
        defb 230, 0
        defb 230, 0
        defb 254, 0
        defb 254, 0
        defb 254, 0
        defb 254, 0
        defb 254, 0
        defb 254, 0
        defb 34, 0
        defb 118, 0
        defb 246, 0
        defb 254, 0
        defb 0, 0
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_16_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
#endasm
 
