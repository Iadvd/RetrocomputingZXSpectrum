// msc.h
// Generado por Mojon Script Compiler de la Churrera
// Copyleft 2011 The Mojon Twins
 
// Script data & pointers
extern unsigned char mscce_0 [];
extern unsigned char mscce_1 [];
extern unsigned char msccf_0 [];
 
unsigned char *e_scripts [] = {
    0, 0, mscce_0, 0, 0, 0, 0, mscce_0, 0, 0, 0, 0, mscce_0, 0, 0, mscce_1, 0, mscce_0, 0, 0
};
 
unsigned char *f_scripts [] = {
    0, 0, msccf_0, 0, 0, 0, 0, msccf_0, 0, 0, 0, 0, msccf_0, 0, 0, 0, 0, msccf_0, 0, 0
};
 
#asm
._mscce_0
    defb 0x0C, 0xF0, 0xFF, 0x20, 0x07, 0x07, 0x14, 0x20, 0x07, 0x08, 0x15, 0xFF
._mscce_1
    defb 0x09, 0x31, 0x19, 0x10, 0x01, 0x0F, 0xFF, 0xF1, 0xFF
._msccf_0
    defb 0x11, 0x21, 0x5C, 0x7F, 0x22, 0x5C, 0x80, 0x40, 0xFF, 0x10, 0x01, 0x01, 0x41, 0x01, 0xE0, 0x07, 0xFF
#endasm
 
unsigned char *script;
 
void msc_init_all () {
    unsigned char i;
    for (i = 0; i < MSC_MAXITEMS; i ++)
        items [i].status = 0;
    for (i = 0; i < MSC_MAXFLAGS; i ++)
        flags [i] = 0;
}
 
unsigned char read_byte () {
    unsigned char c;
    c = script [0];
    script ++;
    return c;
}
 
// Ejecutamos el script apuntado por *script:
unsigned char run_script () {
    unsigned char res = 0;
    unsigned char terminado = 0;
    unsigned char continuar = 0;
    unsigned char x, y, n, c;
 
    if (script == 0)
        return; 
 
    while (!terminado) {
        c = read_byte ();
        switch (c) {
            case 0x10:
                // IF FLAG x = n
                // Opcode: 10 x n
                x = read_byte ();
                n = read_byte ();
                if (flags [x] != n)
                    terminado = 1;
                break;
            case 0x21:
                // IF PLAYER_IN_X x1, x2
                // Opcode: 21 x1 x2
                x = read_byte ();
                y = read_byte ();
                if (!((player.x >> 6) >= x && (player.x >> 6) <= y))
                    terminado = 1;
                break;
            case 0x22:
                // IF PLAYER_IN_Y y1, y2
                // Opcode: 22 y1 y2
                x = read_byte ();
                y = read_byte ();
                if (!((player.y >> 6) >= x && (player.y >> 6) <= y))
                    terminado = 1;
                break;
            case 0x31:
                // IF ENEMIES_KILLED_EQUALS n
                // Opcode: 31 n
                n = read_byte ();
                if (player.killed != n)
                    terminado = 1;
                break;
            case 0x40:
                 // IF PLAYER_HAS_OBJECTS
                 // Opcode: 40
                 if (player.objs == 0)
                     terminado = 1;
                 break;
            case 0xF0:
                 // IF TRUE
                 // Opcode: F0
                 break;
            case 0xFF:
                // THEN
                // Opcode: FF
                terminado = 1;
                continuar = 1;
                break;
        }
    }
    if (continuar) {
        terminado = 0;
        while (!terminado) {
            c = read_byte ();
            switch (c) {
                case 0x10:
                    // INC FLAG x, n
                    // Opcode: 10 x n
                    x = read_byte ();
                    n = read_byte ();
                    flags [x] += n;
                    break;
                case 0x20:
                    // SET TILE (x, y) = n
                    // Opcode: 20 x y n
                    x = read_byte ();
                    y = read_byte ();
                    n = read_byte ();
                    map_buff [x + (y << 4) - y] = n;
                    map_attr [x + (y << 4) - y] = comportamiento_tiles [n];
                    draw_coloured_tile (VIEWPORT_X + x + x, VIEWPORT_Y + y + y, n);
                    break;
                case 0x41:
                    // DEC OBJECTS n
                    // Opcode: 41 n
                    n = read_byte ();
                    player.objs -= n;
                    break;
                case 0xE0:
                    // SOUND n
                    // Opcode: E0 n
                    n = read_byte ();
                    peta_el_beeper (n);
                    break;
                case 0xF1:
                    script_result = 1;
                    terminado = 1;
                    break;
                case 0xFF:
                    terminado = 1;
                    break;
            }
        }
    }
 
    return res;
}
