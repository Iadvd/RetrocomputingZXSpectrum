// msc.h
// Generado por Mojon Script Compiler de la Churrera 4.7 / 3.99.2
// Copyleft 2013 The Mojon Twins
 
 
unsigned char script_result = 0;
unsigned char script_something_done = 0;
 
