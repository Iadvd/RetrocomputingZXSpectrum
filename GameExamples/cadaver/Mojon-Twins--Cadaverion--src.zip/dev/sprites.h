// Sprites.h
// Generado por SprCnv de la Churrera
// Copyleft 2010 The Mojon Twins
 
extern unsigned char sprite_1_a []; 
extern unsigned char sprite_1_b []; 
extern unsigned char sprite_1_c []; 
extern unsigned char sprite_2_a []; 
extern unsigned char sprite_2_b []; 
extern unsigned char sprite_2_c []; 
extern unsigned char sprite_3_a []; 
extern unsigned char sprite_3_b []; 
extern unsigned char sprite_3_c []; 
extern unsigned char sprite_4_a []; 
extern unsigned char sprite_4_b []; 
extern unsigned char sprite_4_c []; 
extern unsigned char sprite_5_a []; 
extern unsigned char sprite_5_b []; 
extern unsigned char sprite_5_c []; 
extern unsigned char sprite_6_a []; 
extern unsigned char sprite_6_b []; 
extern unsigned char sprite_6_c []; 
extern unsigned char sprite_7_a []; 
extern unsigned char sprite_7_b []; 
extern unsigned char sprite_7_c []; 
extern unsigned char sprite_8_a []; 
extern unsigned char sprite_8_b []; 
extern unsigned char sprite_8_c []; 
extern unsigned char sprite_9_a []; 
extern unsigned char sprite_9_b []; 
extern unsigned char sprite_9_c []; 
extern unsigned char sprite_10_a []; 
extern unsigned char sprite_10_b []; 
extern unsigned char sprite_10_c []; 
extern unsigned char sprite_11_a []; 
extern unsigned char sprite_11_b []; 
extern unsigned char sprite_11_c []; 
extern unsigned char sprite_12_a []; 
extern unsigned char sprite_12_b []; 
extern unsigned char sprite_12_c []; 
extern unsigned char sprite_13_a []; 
extern unsigned char sprite_13_b []; 
extern unsigned char sprite_13_c []; 
extern unsigned char sprite_14_a []; 
extern unsigned char sprite_14_b []; 
extern unsigned char sprite_14_c []; 
extern unsigned char sprite_15_a []; 
extern unsigned char sprite_15_b []; 
extern unsigned char sprite_15_c []; 
extern unsigned char sprite_16_a []; 
extern unsigned char sprite_16_b []; 
extern unsigned char sprite_16_c []; 
 
#asm
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_1_a
        defb 2, 240
        defb 5, 128
        defb 55, 0
        defb 38, 0
        defb 62, 0
        defb 24, 128
        defb 1, 192
        defb 2, 240
        defb 2, 240
        defb 2, 240
        defb 2, 240
        defb 2, 240
        defb 1, 248
        defb 1, 252
        defb 1, 252
        defb 1, 252
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_1_b
        defb 224, 7
        defb 240, 3
        defb 0, 3
        defb 168, 1
        defb 168, 1
        defb 240, 3
        defb 0, 7
        defb 160, 7
        defb 208, 3
        defb 216, 1
        defb 0, 1
        defb 208, 3
        defb 192, 3
        defb 64, 7
        defb 64, 7
        defb 160, 3
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_1_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_2_a
        defb 0, 255
        defb 2, 128
        defb 53, 0
        defb 39, 0
        defb 62, 0
        defb 28, 128
        defb 0, 192
        defb 1, 248
        defb 2, 240
        defb 2, 240
        defb 2, 240
        defb 2, 240
        defb 0, 248
        defb 0, 224
        defb 15, 192
        defb 8, 192
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_2_b
        defb 0, 255
        defb 224, 7
        defb 240, 3
        defb 0, 3
        defb 168, 1
        defb 168, 1
        defb 240, 3
        defb 0, 3
        defb 216, 1
        defb 208, 3
        defb 0, 7
        defb 96, 8
        defb 194, 0
        defb 126, 0
        defb 0, 0
        defb 0, 127
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_2_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_3_a
        defb 7, 224
        defb 15, 192
        defb 0, 192
        defb 21, 128
        defb 21, 128
        defb 15, 192
        defb 0, 224
        defb 5, 224
        defb 11, 192
        defb 27, 128
        defb 0, 128
        defb 11, 192
        defb 3, 192
        defb 2, 224
        defb 2, 224
        defb 5, 192
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_3_b
        defb 64, 15
        defb 160, 1
        defb 236, 0
        defb 100, 0
        defb 124, 0
        defb 24, 1
        defb 128, 3
        defb 64, 15
        defb 64, 15
        defb 64, 15
        defb 64, 15
        defb 64, 15
        defb 128, 31
        defb 128, 63
        defb 128, 63
        defb 128, 63
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_3_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_4_a
        defb 0, 255
        defb 7, 224
        defb 15, 192
        defb 0, 192
        defb 21, 128
        defb 21, 128
        defb 15, 192
        defb 0, 192
        defb 27, 128
        defb 11, 192
        defb 0, 224
        defb 6, 16
        defb 67, 0
        defb 126, 0
        defb 0, 0
        defb 0, 254
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_4_b
        defb 0, 255
        defb 64, 1
        defb 172, 0
        defb 228, 0
        defb 124, 0
        defb 56, 1
        defb 0, 3
        defb 128, 31
        defb 64, 15
        defb 64, 15
        defb 64, 15
        defb 64, 15
        defb 0, 31
        defb 0, 7
        defb 240, 3
        defb 16, 3
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_4_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_5_a
        defb 3, 224
        defb 7, 128
        defb 55, 0
        defb 39, 0
        defb 63, 0
        defb 28, 128
        defb 1, 192
        defb 7, 224
        defb 11, 192
        defb 9, 192
        defb 11, 192
        defb 11, 192
        defb 2, 224
        defb 1, 248
        defb 1, 248
        defb 3, 240
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_5_b
        defb 192, 7
        defb 224, 1
        defb 236, 0
        defb 228, 0
        defb 252, 0
        defb 24, 1
        defb 128, 3
        defb 192, 15
        defb 224, 7
        defb 144, 3
        defb 64, 7
        defb 96, 7
        defb 32, 7
        defb 48, 3
        defb 0, 3
        defb 0, 63
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_5_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_6_a
        defb 3, 224
        defb 7, 128
        defb 55, 0
        defb 39, 0
        defb 63, 0
        defb 24, 128
        defb 1, 192
        defb 3, 240
        defb 7, 224
        defb 9, 192
        defb 2, 224
        defb 6, 224
        defb 4, 224
        defb 12, 192
        defb 0, 192
        defb 0, 252
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_6_b
        defb 192, 7
        defb 224, 1
        defb 236, 0
        defb 228, 0
        defb 252, 0
        defb 56, 1
        defb 128, 3
        defb 224, 7
        defb 208, 3
        defb 144, 3
        defb 208, 3
        defb 208, 3
        defb 64, 7
        defb 128, 31
        defb 128, 31
        defb 192, 15
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_6_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_7_a
        defb 3, 224
        defb 7, 128
        defb 52, 0
        defb 34, 0
        defb 58, 0
        defb 27, 128
        defb 0, 192
        defb 7, 224
        defb 11, 192
        defb 11, 192
        defb 8, 192
        defb 11, 192
        defb 2, 224
        defb 1, 248
        defb 1, 248
        defb 3, 240
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_7_b
        defb 192, 7
        defb 224, 1
        defb 12, 0
        defb 164, 0
        defb 188, 0
        defb 216, 1
        defb 0, 3
        defb 192, 15
        defb 96, 7
        defb 96, 3
        defb 0, 7
        defb 224, 7
        defb 32, 7
        defb 48, 3
        defb 0, 3
        defb 0, 63
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_7_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_8_a
        defb 3, 224
        defb 7, 128
        defb 48, 0
        defb 37, 0
        defb 61, 0
        defb 27, 128
        defb 0, 192
        defb 3, 240
        defb 6, 224
        defb 6, 192
        defb 0, 224
        defb 7, 224
        defb 4, 224
        defb 12, 192
        defb 0, 192
        defb 0, 252
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_8_b
        defb 192, 7
        defb 224, 1
        defb 44, 0
        defb 68, 0
        defb 92, 0
        defb 216, 1
        defb 0, 3
        defb 224, 7
        defb 208, 3
        defb 208, 3
        defb 16, 3
        defb 208, 3
        defb 64, 7
        defb 128, 31
        defb 128, 31
        defb 192, 15
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_8_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_9_a
        defb 0, 240
        defb 5, 224
        defb 10, 192
        defb 16, 128
        defb 32, 0
        defb 79, 0
        defb 40, 0
        defb 77, 0
        defb 39, 0
        defb 18, 0
        defb 35, 0
        defb 65, 0
        defb 64, 0
        defb 32, 0
        defb 11, 128
        defb 24, 192
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_9_b
        defb 0, 7
        defb 80, 3
        defb 168, 1
        defb 4, 0
        defb 2, 0
        defb 244, 0
        defb 18, 0
        defb 177, 0
        defb 226, 0
        defb 76, 0
        defb 66, 0
        defb 193, 0
        defb 1, 0
        defb 6, 0
        defb 208, 0
        defb 24, 3
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_9_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_10_a
        defb 0, 224
        defb 10, 192
        defb 21, 128
        defb 32, 0
        defb 64, 0
        defb 47, 0
        defb 72, 0
        defb 141, 0
        defb 71, 0
        defb 50, 0
        defb 66, 0
        defb 131, 0
        defb 128, 0
        defb 96, 0
        defb 11, 0
        defb 24, 192
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_10_b
        defb 0, 15
        defb 160, 7
        defb 80, 3
        defb 8, 1
        defb 4, 0
        defb 242, 0
        defb 20, 0
        defb 178, 0
        defb 228, 0
        defb 72, 0
        defb 196, 0
        defb 130, 0
        defb 2, 0
        defb 4, 0
        defb 208, 1
        defb 24, 3
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_10_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_11_a
        defb 0, 195
        defb 60, 129
        defb 124, 1
        defb 248, 3
        defb 248, 1
        defb 250, 0
        defb 255, 0
        defb 253, 0
        defb 247, 0
        defb 254, 0
        defb 117, 0
        defb 119, 0
        defb 19, 128
        defb 0, 236
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_11_b
        defb 0, 195
        defb 60, 129
        defb 62, 128
        defb 31, 192
        defb 31, 128
        defb 95, 0
        defb 255, 0
        defb 191, 0
        defb 239, 0
        defb 127, 0
        defb 174, 0
        defb 238, 0
        defb 200, 1
        defb 0, 55
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_11_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_12_a
        defb 0, 255
        defb 0, 223
        defb 32, 141
        defb 66, 24
        defb 67, 24
        defb 101, 0
        defb 247, 0
        defb 254, 0
        defb 245, 0
        defb 255, 0
        defb 251, 0
        defb 252, 0
        defb 124, 1
        defb 124, 1
        defb 30, 128
        defb 6, 224
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_12_b
        defb 0, 255
        defb 0, 251
        defb 4, 177
        defb 66, 24
        defb 194, 24
        defb 166, 0
        defb 239, 0
        defb 127, 0
        defb 175, 0
        defb 255, 0
        defb 223, 0
        defb 63, 0
        defb 62, 128
        defb 62, 128
        defb 120, 1
        defb 96, 7
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_12_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_13_a
        defb 1, 248
        defb 3, 24
        defb 66, 8
        defb 162, 0
        defb 34, 0
        defb 35, 0
        defb 27, 128
        defb 1, 192
        defb 0, 248
        defb 1, 248
        defb 0, 248
        defb 1, 224
        defb 12, 192
        defb 19, 192
        defb 16, 0
        defb 112, 7
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_13_b
        defb 128, 31
        defb 192, 8
        defb 163, 0
        defb 165, 0
        defb 164, 0
        defb 229, 0
        defb 104, 0
        defb 32, 3
        defb 0, 7
        defb 240, 0
        defb 70, 0
        defb 234, 0
        defb 82, 0
        defb 227, 0
        defb 0, 8
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_13_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_14_a
        defb 1, 248
        defb 3, 16
        defb 197, 0
        defb 165, 0
        defb 37, 0
        defb 167, 0
        defb 22, 0
        defb 4, 192
        defb 0, 224
        defb 15, 0
        defb 98, 0
        defb 87, 0
        defb 74, 0
        defb 199, 0
        defb 0, 16
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_14_b
        defb 128, 31
        defb 192, 24
        defb 66, 16
        defb 69, 0
        defb 68, 0
        defb 196, 0
        defb 216, 1
        defb 128, 3
        defb 0, 31
        defb 128, 31
        defb 0, 31
        defb 128, 7
        defb 48, 3
        defb 200, 3
        defb 8, 0
        defb 14, 224
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_14_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_15_a
        defb 0, 255
        defb 0, 254
        defb 0, 192
        defb 25, 128
        defb 47, 128
        defb 60, 128
        defb 27, 128
        defb 12, 192
        defb 54, 0
        defb 71, 0
        defb 83, 0
        defb 201, 0
        defb 212, 0
        defb 10, 0
        defb 24, 128
        defb 56, 131
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_15_b
        defb 0, 255
        defb 0, 7
        defb 240, 3
        defb 232, 3
        defb 248, 3
        defb 248, 1
        defb 68, 1
        defb 92, 1
        defb 232, 1
        defb 104, 1
        defb 148, 1
        defb 228, 0
        defb 6, 0
        defb 166, 0
        defb 96, 0
        defb 112, 7
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_15_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_16_a
        defb 0, 255
        defb 0, 252
        defb 1, 128
        defb 51, 0
        defb 95, 0
        defb 121, 0
        defb 54, 0
        defb 24, 128
        defb 13, 128
        defb 14, 128
        defb 39, 128
        defb 35, 0
        defb 104, 0
        defb 101, 0
        defb 6, 0
        defb 14, 224
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_16_b
        defb 0, 255
        defb 0, 15
        defb 224, 7
        defb 208, 7
        defb 240, 7
        defb 240, 3
        defb 136, 3
        defb 184, 3
        defb 208, 0
        defb 210, 0
        defb 42, 0
        defb 195, 0
        defb 11, 0
        defb 80, 0
        defb 24, 1
        defb 28, 193
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_16_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
#endasm
 
