// External custom code to be run from a script

void do_extern_action (unsigned char n) {
	// Add custom code here.	
}
